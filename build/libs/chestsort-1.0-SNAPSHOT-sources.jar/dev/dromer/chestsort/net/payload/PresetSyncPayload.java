package dev.dromer.chestsort.net.payload;

import dev.dromer.chestsort.Chestsort;
import dev.dromer.chestsort.filter.ContainerFilterSpec;
import dev.dromer.chestsort.filter.TagFilterSpec;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server -> Client: full preset list sync. */
public record PresetSyncPayload(List<String> names, List<ContainerFilterSpec> specs) implements class_8710 {
    public static final class_9154<PresetSyncPayload> ID = new class_9154<>(class_2960.method_60655(Chestsort.MOD_ID, "preset_sync"));

    public static final class_9139<class_9129, PresetSyncPayload> CODEC = class_9139.method_56437(
        (buf, payload) -> {
            List<String> names = payload.names == null ? List.of() : payload.names;
            List<ContainerFilterSpec> specs = payload.specs == null ? List.of() : payload.specs;
            int n = Math.min(names.size(), specs.size());
            buf.method_10804(n);
            for (int i = 0; i < n; i++) {
                String name = names.get(i);
                buf.method_10814(name == null ? "" : name);

                ContainerFilterSpec spec = specs.get(i);
                ContainerFilterSpec safe = spec == null ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : spec;
                List<String> items = safe.items() == null ? List.of() : safe.items();
                List<TagFilterSpec> tags = safe.tags() == null ? List.of() : safe.tags();

                buf.method_10804(items.size());
                for (String itemId : items) {
                    buf.method_10814(itemId == null ? "" : itemId);
                }

                buf.method_10804(tags.size());
                for (TagFilterSpec tag : tags) {
                    String tagId = tag == null ? "" : (tag.tagId() == null ? "" : tag.tagId());
                    buf.method_10814(tagId);
                    List<String> exceptions = (tag == null || tag.exceptions() == null) ? List.of() : tag.exceptions();
                    buf.method_10804(exceptions.size());
                    for (String exc : exceptions) {
                        buf.method_10814(exc == null ? "" : exc);
                    }
                }
            }
        },
        buf -> {
            int n = buf.method_10816();
            ArrayList<String> names = new ArrayList<>(Math.max(0, n));
            ArrayList<ContainerFilterSpec> specs = new ArrayList<>(Math.max(0, n));
            for (int i = 0; i < n; i++) {
                String name = buf.method_19772();
                int itemsN = buf.method_10816();
                ArrayList<String> items = new ArrayList<>(Math.max(0, itemsN));
                for (int j = 0; j < itemsN; j++) {
                    items.add(buf.method_19772());
                }

                int tagsN = buf.method_10816();
                ArrayList<TagFilterSpec> tags = new ArrayList<>(Math.max(0, tagsN));
                for (int t = 0; t < tagsN; t++) {
                    String tagId = buf.method_19772();
                    int excN = buf.method_10816();
                    ArrayList<String> exc = new ArrayList<>(Math.max(0, excN));
                    for (int e = 0; e < excN; e++) {
                        exc.add(buf.method_19772());
                    }
                    tags.add(new TagFilterSpec(tagId, exc));
                }

                names.add(name);
                specs.add(new ContainerFilterSpec(items, tags, List.of()).normalized());
            }
            return new PresetSyncPayload(names, specs);
        }
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
