package dev.dromer.chestsort.net.payload;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import dev.dromer.chestsort.Chestsort;

/** Server -> client: current protected player inventory slot indices. */
public record LockedSlotsSyncPayload(List<Integer> lockedSlots) implements class_8710 {
    public static final class_9154<LockedSlotsSyncPayload> ID = new class_9154<>(class_2960.method_60655(Chestsort.MOD_ID, "locked_slots_sync"));

    public static final class_9139<class_9129, LockedSlotsSyncPayload> CODEC = class_9139.method_56437(
        (buf, payload) -> {
            List<Integer> list = payload.lockedSlots == null ? List.of() : payload.lockedSlots;
            buf.method_10804(list.size());
            for (Integer i : list) {
                buf.method_10804(i == null ? -1 : i);
            }
        },
        buf -> {
            int n = buf.method_10816();
            ArrayList<Integer> out = new ArrayList<>(Math.max(0, n));
            for (int k = 0; k < n; k++) {
                out.add(buf.method_10816());
            }
            return new LockedSlotsSyncPayload(out);
        }
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
