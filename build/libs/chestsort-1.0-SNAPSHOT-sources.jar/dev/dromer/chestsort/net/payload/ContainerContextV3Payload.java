package dev.dromer.chestsort.net.payload;

import dev.dromer.chestsort.Chestsort;
import dev.dromer.chestsort.filter.ContainerFilterSpec;
import dev.dromer.chestsort.filter.TagFilterSpec;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ContainerContextV3Payload(
    String dimensionId,
    long posLong,
    String containerType,
    ContainerFilterSpec whitelist,
    ContainerFilterSpec blacklist,
    boolean whitelistPriority
) implements class_8710 {
    public static final class_9154<ContainerContextV3Payload> ID = new class_9154<>(class_2960.method_60655(Chestsort.MOD_ID, "container_context_v3"));

    public static final class_9139<class_9129, ContainerContextV3Payload> CODEC = class_9139.method_56437(
        (buf, payload) -> {
            buf.method_10814(payload.dimensionId == null ? "" : payload.dimensionId);
            buf.method_52974(payload.posLong);
            buf.method_10814(payload.containerType == null ? "" : payload.containerType);

            writeSpec(buf, payload.whitelist);
            writeSpec(buf, payload.blacklist);

            buf.method_52964(payload.whitelistPriority);
        },
        buf -> {
            String dim = buf.method_19772();
            long pos = buf.readLong();
            String type = buf.method_19772();

            ContainerFilterSpec whitelist = readSpec(buf);
            ContainerFilterSpec blacklist = readSpec(buf);

            boolean whitelistPriority = buf.readBoolean();

            return new ContainerContextV3Payload(dim, pos, type, whitelist, blacklist, whitelistPriority);
        }
    );

    private static void writeSpec(class_9129 buf, ContainerFilterSpec specRaw) {
        ContainerFilterSpec spec = specRaw == null ? new ContainerFilterSpec(List.of(), List.of(), List.of(), false) : specRaw.normalized();
        List<String> items = spec.items() == null ? List.of() : spec.items();
        List<TagFilterSpec> tags = spec.tags() == null ? List.of() : spec.tags();
        List<String> presets = spec.presets() == null ? List.of() : spec.presets();

        buf.method_10804(items.size());
        for (String itemId : items) {
            buf.method_10814(itemId == null ? "" : itemId);
        }

        buf.method_10804(tags.size());
        for (TagFilterSpec tag : tags) {
            String tagId = tag == null ? "" : (tag.tagId() == null ? "" : tag.tagId());
            buf.method_10814(tagId);
            List<String> exceptions = (tag == null || tag.exceptions() == null) ? List.of() : tag.exceptions();
            buf.method_10804(exceptions.size());
            for (String exc : exceptions) {
                buf.method_10814(exc == null ? "" : exc);
            }
        }

        buf.method_10804(presets.size());
        for (String name : presets) {
            buf.method_10814(name == null ? "" : name);
        }

        buf.method_52964(spec.autosort());
    }

    private static ContainerFilterSpec readSpec(class_9129 buf) {
        int nItems = buf.method_10816();
        List<String> items = new ArrayList<>(Math.max(0, nItems));
        for (int i = 0; i < nItems; i++) {
            items.add(buf.method_19772());
        }

        int nTags = buf.method_10816();
        List<TagFilterSpec> tags = new ArrayList<>(Math.max(0, nTags));
        for (int i = 0; i < nTags; i++) {
            String tagId = buf.method_19772();
            int nExc = buf.method_10816();
            List<String> exceptions = new ArrayList<>(Math.max(0, nExc));
            for (int j = 0; j < nExc; j++) {
                exceptions.add(buf.method_19772());
            }
            tags.add(new TagFilterSpec(tagId, exceptions));
        }

        int nPresets = buf.method_10816();
        List<String> presets = new ArrayList<>(Math.max(0, nPresets));
        for (int i = 0; i < nPresets; i++) {
            presets.add(buf.method_19772());
        }

        boolean autosort = buf.readBoolean();

        return new ContainerFilterSpec(items, tags, presets, autosort).normalized();
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
