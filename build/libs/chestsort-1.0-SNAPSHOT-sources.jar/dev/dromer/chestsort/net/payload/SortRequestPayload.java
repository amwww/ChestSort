package dev.dromer.chestsort.net.payload;

import dev.dromer.chestsort.Chestsort;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SortRequestPayload(String dimensionId, long posLong) implements class_8710 {
    public static final class_9154<SortRequestPayload> ID = new class_9154<>(class_2960.method_60655(Chestsort.MOD_ID, "sort"));

    public static final class_9139<class_9129, SortRequestPayload> CODEC = class_9139.method_56437(
        (buf, payload) -> {
            buf.method_10814(payload.dimensionId == null ? "" : payload.dimensionId);
            buf.method_52974(payload.posLong);
        },
        buf -> new SortRequestPayload(buf.method_19772(), buf.readLong())
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
