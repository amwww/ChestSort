package dev.dromer.chestsort.net.payload;

import dev.dromer.chestsort.Chestsort;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server -> Client: request opening the preset UI inside the container filter screen. */
public record OpenPresetUiPayload(byte mode, String name) implements class_8710 {
    /** Open the preset editor for an existing/new preset name. */
    public static final byte MODE_EDIT = 0;
    /** Open the preset-import popup (paste export code). */
    public static final byte MODE_IMPORT = 1;
    /** Open the preset-export popup (copy export code). */
    public static final byte MODE_EXPORT = 2;
    /** Open the preset-export-all screen (exports all presets as a presetList). */
    public static final byte MODE_EXPORT_ALL = 3;
    /** Open the preset-export-select screen (choose presets to export as a presetList). */
    public static final byte MODE_EXPORT_SELECT = 4;

    public static final class_9154<OpenPresetUiPayload> ID = new class_9154<>(class_2960.method_60655(Chestsort.MOD_ID, "open_preset_ui"));

    public static final class_9139<class_9129, OpenPresetUiPayload> CODEC = class_9139.method_56437(
        (buf, payload) -> {
            buf.method_52997(payload.mode);
            buf.method_10814(payload.name == null ? "" : payload.name);
        },
        buf -> new OpenPresetUiPayload(buf.readByte(), buf.method_19772())
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
