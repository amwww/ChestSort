package dev.dromer.chestsort.net.payload;

import dev.dromer.chestsort.Chestsort;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server -> client: current wand binding + selection (for rendering/UX). */
public record WandSelectionPayload(
    String wandItemId,
    boolean hasPos1,
    String pos1DimensionId,
    long pos1Long,
    boolean hasPos2,
    String pos2DimensionId,
    long pos2Long,
    long blockCount,
    int containerCount
) implements class_8710 {
    public static final class_9154<WandSelectionPayload> ID = new class_9154<>(class_2960.method_60655(Chestsort.MOD_ID, "wand_selection"));

    public static final class_9139<class_9129, WandSelectionPayload> CODEC = class_9139.method_56437(
        (buf, payload) -> {
            buf.method_10814(payload.wandItemId == null ? "" : payload.wandItemId);

            buf.method_52964(payload.hasPos1);
            buf.method_10814(payload.pos1DimensionId == null ? "" : payload.pos1DimensionId);
            buf.method_52974(payload.pos1Long);

            buf.method_52964(payload.hasPos2);
            buf.method_10814(payload.pos2DimensionId == null ? "" : payload.pos2DimensionId);
            buf.method_52974(payload.pos2Long);

            buf.method_52974(payload.blockCount);
            buf.method_10804(payload.containerCount);
        },
        buf -> new WandSelectionPayload(
            buf.method_19772(),
            buf.readBoolean(),
            buf.method_19772(),
            buf.readLong(),
            buf.readBoolean(),
            buf.method_19772(),
            buf.readLong(),
            buf.readLong(),
            buf.method_10816()
        )
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
