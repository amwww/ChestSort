package dev.dromer.chestsort.net.payload;

import dev.dromer.chestsort.Chestsort;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ContainerHighlightPayload(String itemId, boolean highlight) implements class_8710 {
    public static final class_9154<ContainerHighlightPayload> ID = new class_9154<>(class_2960.method_60655(Chestsort.MOD_ID, "container_highlight"));

    public static final class_9139<class_9129, ContainerHighlightPayload> CODEC = class_9139.method_56437(
        (buf, payload) -> {
            buf.method_10814(payload.itemId == null ? "" : payload.itemId);
            buf.method_52964(payload.highlight);
        },
        buf -> new ContainerHighlightPayload(buf.method_19772(), buf.readBoolean())
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
