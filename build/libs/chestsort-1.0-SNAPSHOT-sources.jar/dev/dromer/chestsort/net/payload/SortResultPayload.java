package dev.dromer.chestsort.net.payload;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import dev.dromer.chestsort.Chestsort;

/**
 * Server-to-client payload describing the outcome of a Sort/Autosort/Undo operation.
 */
public record SortResultPayload(
    String dimensionId,
    long posLong,
    byte kind,
    String autosortMode,
    boolean containerAutosort,
    long undoId,
    int movedTotal,
    List<SortLine> lines
) implements class_8710 {

    public static final byte KIND_SORT = 0;
    public static final byte KIND_AUTOSORT = 1;
    public static final byte KIND_UNDO = 2;
    public static final byte KIND_ORGANIZE = 3;

    public static final class_9154<SortResultPayload> ID = new class_9154<>(class_2960.method_60655(Chestsort.MOD_ID, "sort_result"));

    public static final class_9139<class_9129, SortResultPayload> CODEC = class_9139.method_56437(
        (buf, payload) -> {
            buf.method_10814(payload.dimensionId == null ? "" : payload.dimensionId);
            buf.method_52974(payload.posLong);
            buf.method_52997(payload.kind);
            buf.method_10814(payload.autosortMode == null ? "" : payload.autosortMode);
            buf.method_52964(payload.containerAutosort);
            buf.method_52974(payload.undoId);
            buf.method_53002(payload.movedTotal);

            List<SortLine> lines = payload.lines == null ? List.of() : payload.lines;
            buf.method_53002(lines.size());
            for (SortLine line : lines) {
                if (line == null) {
                    buf.method_10814("");
                    buf.method_53002(0);
                    buf.method_53002(0);
                    continue;
                }
                buf.method_10814(line.itemId == null ? "" : line.itemId);
                buf.method_53002(line.count);
                List<String> reasons = line.reasons == null ? List.of() : line.reasons;
                buf.method_53002(reasons.size());
                for (String r : reasons) {
                    buf.method_10814(r == null ? "" : r);
                }
            }
        },
        buf -> {
            String dimId = buf.method_19772();
            long posLong = buf.readLong();
            byte kind = buf.readByte();
            String autosortMode = buf.method_19772();
            boolean containerAutosort = buf.readBoolean();
            long undoId = buf.readLong();
            int movedTotal = buf.readInt();

            int n = buf.readInt();
            ArrayList<SortLine> lines = new ArrayList<>(Math.max(0, n));
            for (int i = 0; i < n; i++) {
                String itemId = buf.method_19772();
                int count = buf.readInt();
                int rn = buf.readInt();
                ArrayList<String> reasons = new ArrayList<>(Math.max(0, rn));
                for (int j = 0; j < rn; j++) {
                    reasons.add(buf.method_19772());
                }
                lines.add(new SortLine(itemId, count, reasons));
            }

            return new SortResultPayload(dimId, posLong, kind, autosortMode, containerAutosort, undoId, movedTotal, lines);
        }
    );

    public record SortLine(String itemId, int count, List<String> reasons) {
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
