package dev.dromer.chestsort.net.payload;

import dev.dromer.chestsort.Chestsort;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Client -> server: select wand pos1/pos2 without interacting/breaking blocks. */
public record WandSelectPayload(byte which, String dimensionId, long posLong) implements class_8710 {
    public static final class_9154<WandSelectPayload> ID = new class_9154<>(class_2960.method_60655(Chestsort.MOD_ID, "wand_select"));

    public static final class_9139<class_9129, WandSelectPayload> CODEC = class_9139.method_56437(
        (buf, payload) -> {
            buf.method_52997(payload.which);
            buf.method_10814(payload.dimensionId == null ? "" : payload.dimensionId);
            buf.method_52974(payload.posLong);
        },
        buf -> new WandSelectPayload(buf.readByte(), buf.method_19772(), buf.readLong())
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
