package dev.dromer.chestsort.net.payload;

import dev.dromer.chestsort.Chestsort;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Sent after running /cs find to highlight matching containers in-world.
 * Only intended for client-side rendering; server remains authoritative.
 */
public record FindHighlightsPayload(String dimensionId, String itemId, List<Long> posLongs) implements class_8710 {
    public static final class_9154<FindHighlightsPayload> ID = new class_9154<>(class_2960.method_60655(Chestsort.MOD_ID, "find_highlights"));

    public static final class_9139<class_9129, FindHighlightsPayload> CODEC = class_9139.method_56437(
        (buf, payload) -> {
            buf.method_10814(payload.dimensionId == null ? "" : payload.dimensionId);
            buf.method_10814(payload.itemId == null ? "" : payload.itemId);
            List<Long> list = payload.posLongs == null ? List.of() : payload.posLongs;
            buf.method_10804(list.size());
            for (Long l : list) {
                buf.method_52974(l == null ? 0L : l);
            }
        },
        buf -> {
            String dim = buf.method_19772();
            String item = buf.method_19772();
            int n = buf.method_10816();
            List<Long> pos = new ArrayList<>(Math.max(0, n));
            for (int i = 0; i < n; i++) {
                pos.add(buf.readLong());
            }
            return new FindHighlightsPayload(dim, item, pos);
        }
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
