package dev.dromer.chestsort.net.payload;

import dev.dromer.chestsort.Chestsort;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Client -> server: toggle whether a player inventory slot is protected from sorting. */
public record ToggleLockedSlotPayload(int playerInventoryIndex) implements class_8710 {
    public static final class_9154<ToggleLockedSlotPayload> ID = new class_9154<>(class_2960.method_60655(Chestsort.MOD_ID, "toggle_locked_slot"));

    public static final class_9139<class_9129, ToggleLockedSlotPayload> CODEC = class_9139.method_56437(
        (buf, payload) -> buf.method_10804(payload.playerInventoryIndex),
        buf -> new ToggleLockedSlotPayload(buf.method_10816())
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
