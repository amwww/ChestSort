package dev.dromer.chestsort.net.payload;

import dev.dromer.chestsort.Chestsort;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Client -> Server: import a preset from a cs2 export string (must be a named preset like `cs2|preset/<name>|...`). */
public record ImportPresetPayload(String data) implements class_8710 {
    public static final class_9154<ImportPresetPayload> ID = new class_9154<>(class_2960.method_60655(Chestsort.MOD_ID, "import_preset"));

    public static final class_9139<class_9129, ImportPresetPayload> CODEC = class_9139.method_56437(
        (buf, payload) -> buf.method_10814(payload.data == null ? "" : payload.data),
        buf -> new ImportPresetPayload(buf.method_19772())
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
