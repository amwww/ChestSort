package dev.dromer.chestsort.net.payload;

import dev.dromer.chestsort.Chestsort;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SetFilterPayload(String dimensionId, long posLong, List<String> filterItems) implements class_8710 {
    public static final class_9154<SetFilterPayload> ID = new class_9154<>(class_2960.method_60655(Chestsort.MOD_ID, "set_filter"));

    public static final class_9139<class_9129, SetFilterPayload> CODEC = class_9139.method_56437(
        (buf, payload) -> {
            buf.method_10814(payload.dimensionId == null ? "" : payload.dimensionId);
            buf.method_52974(payload.posLong);
            List<String> items = payload.filterItems == null ? List.of() : payload.filterItems;
            buf.method_10804(items.size());
            for (String itemId : items) {
                buf.method_10814(itemId == null ? "" : itemId);
            }
        },
        buf -> {
            String dim = buf.method_19772();
            long pos = buf.readLong();
            int n = buf.method_10816();
            List<String> items = new ArrayList<>(Math.max(0, n));
            for (int i = 0; i < n; i++) {
                items.add(buf.method_19772());
            }
            return new SetFilterPayload(dim, pos, items);
        }
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
