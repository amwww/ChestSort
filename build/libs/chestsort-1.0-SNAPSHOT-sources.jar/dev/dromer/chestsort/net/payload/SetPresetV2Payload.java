package dev.dromer.chestsort.net.payload;

import dev.dromer.chestsort.Chestsort;
import dev.dromer.chestsort.filter.ContainerFilterSpec;
import dev.dromer.chestsort.filter.TagFilterSpec;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Client -> Server: set (create/update) a preset by name (whitelist + blacklist). */
public record SetPresetV2Payload(String name, ContainerFilterSpec whitelist, ContainerFilterSpec blacklist) implements class_8710 {
    public static final class_9154<SetPresetV2Payload> ID = new class_9154<>(class_2960.method_60655(Chestsort.MOD_ID, "set_preset_v2"));

    public static final class_9139<class_9129, SetPresetV2Payload> CODEC = class_9139.method_56437(
        (buf, payload) -> {
            buf.method_10814(payload.name == null ? "" : payload.name);
            writeSpec(buf, payload.whitelist);
            writeSpec(buf, payload.blacklist);
        },
        buf -> {
            String name = buf.method_19772();
            ContainerFilterSpec wl = readSpec(buf);
            ContainerFilterSpec bl = readSpec(buf);
            return new SetPresetV2Payload(name, wl, bl);
        }
    );

    private static void writeSpec(class_9129 buf, ContainerFilterSpec spec) {
        ContainerFilterSpec safe = spec == null ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : spec;
        List<String> items = safe.items() == null ? List.of() : safe.items();
        List<TagFilterSpec> tags = safe.tags() == null ? List.of() : safe.tags();

        buf.method_10804(items.size());
        for (String itemId : items) {
            buf.method_10814(itemId == null ? "" : itemId);
        }

        buf.method_10804(tags.size());
        for (TagFilterSpec tag : tags) {
            String tagId = tag == null ? "" : (tag.tagId() == null ? "" : tag.tagId());
            buf.method_10814(tagId);
            List<String> exceptions = (tag == null || tag.exceptions() == null) ? List.of() : tag.exceptions();
            buf.method_10804(exceptions.size());
            for (String exc : exceptions) {
                buf.method_10814(exc == null ? "" : exc);
            }
        }
    }

    private static ContainerFilterSpec readSpec(class_9129 buf) {
        int itemsN = buf.method_10816();
        ArrayList<String> items = new ArrayList<>(Math.max(0, itemsN));
        for (int j = 0; j < itemsN; j++) {
            items.add(buf.method_19772());
        }

        int tagsN = buf.method_10816();
        ArrayList<TagFilterSpec> tags = new ArrayList<>(Math.max(0, tagsN));
        for (int t = 0; t < tagsN; t++) {
            String tagId = buf.method_19772();
            int excN = buf.method_10816();
            ArrayList<String> exc = new ArrayList<>(Math.max(0, excN));
            for (int e = 0; e < excN; e++) {
                exc.add(buf.method_19772());
            }
            tags.add(new TagFilterSpec(tagId, exc));
        }

        return new ContainerFilterSpec(items, tags, List.of()).normalized();
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
