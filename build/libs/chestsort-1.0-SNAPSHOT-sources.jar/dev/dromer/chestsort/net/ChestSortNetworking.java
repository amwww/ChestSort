package dev.dromer.chestsort.net;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import dev.dromer.chestsort.data.ChestSortState;
import dev.dromer.chestsort.filter.ContainerFilterSpec;
import dev.dromer.chestsort.filter.TagFilterSpec;
import dev.dromer.chestsort.net.payload.ContainerContextPayload;
import dev.dromer.chestsort.net.payload.ContainerContextV2Payload;
import dev.dromer.chestsort.net.payload.ContainerContextV3Payload;
import dev.dromer.chestsort.net.payload.ContainerHighlightPayload;
import dev.dromer.chestsort.net.payload.FindHighlightsPayload;
import dev.dromer.chestsort.net.payload.ImportPresetListPayload;
import dev.dromer.chestsort.net.payload.ImportPresetPayload;
import dev.dromer.chestsort.net.payload.LockedSlotsSyncPayload;
import dev.dromer.chestsort.net.payload.OpenPresetUiPayload;
import dev.dromer.chestsort.net.payload.OrganizeRequestPayload;
import dev.dromer.chestsort.net.payload.PresetSyncPayload;
import dev.dromer.chestsort.net.payload.PresetSyncV2Payload;
import dev.dromer.chestsort.net.payload.SetContainerFiltersPayload;
import dev.dromer.chestsort.net.payload.SetFilterPayload;
import dev.dromer.chestsort.net.payload.SetFilterV2Payload;
import dev.dromer.chestsort.net.payload.SetPresetPayload;
import dev.dromer.chestsort.net.payload.SetPresetV2Payload;
import dev.dromer.chestsort.net.payload.SortRequestPayload;
import dev.dromer.chestsort.net.payload.SortResultPayload;
import dev.dromer.chestsort.net.payload.ToggleLockedSlotPayload;
import dev.dromer.chestsort.net.payload.UndoSortPayload;
import dev.dromer.chestsort.net.payload.WandSelectPayload;
import dev.dromer.chestsort.net.payload.WandSelectionPayload;
import dev.dromer.chestsort.util.ContainerCanonicalizer;
import dev.dromer.chestsort.util.Cs2StringCodec;
import dev.dromer.chestsort.util.WandSelectionUtil;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3719;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ChestSortNetworking {
    private ChestSortNetworking() {
    }

    public static void init() {
        PayloadTypeRegistry.playS2C().register(ContainerHighlightPayload.ID, ContainerHighlightPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(FindHighlightsPayload.ID, FindHighlightsPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(ContainerContextPayload.ID, ContainerContextPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(ContainerContextV2Payload.ID, ContainerContextV2Payload.CODEC);
        PayloadTypeRegistry.playS2C().register(ContainerContextV3Payload.ID, ContainerContextV3Payload.CODEC);
        PayloadTypeRegistry.playS2C().register(PresetSyncPayload.ID, PresetSyncPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(PresetSyncV2Payload.ID, PresetSyncV2Payload.CODEC);
        PayloadTypeRegistry.playS2C().register(OpenPresetUiPayload.ID, OpenPresetUiPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SortResultPayload.ID, SortResultPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(WandSelectionPayload.ID, WandSelectionPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(LockedSlotsSyncPayload.ID, LockedSlotsSyncPayload.CODEC);

        PayloadTypeRegistry.playC2S().register(SetFilterPayload.ID, SetFilterPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SetFilterV2Payload.ID, SetFilterV2Payload.CODEC);
        PayloadTypeRegistry.playC2S().register(SetContainerFiltersPayload.ID, SetContainerFiltersPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SortRequestPayload.ID, SortRequestPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(OrganizeRequestPayload.ID, OrganizeRequestPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(UndoSortPayload.ID, UndoSortPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SetPresetPayload.ID, SetPresetPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SetPresetV2Payload.ID, SetPresetV2Payload.CODEC);
        PayloadTypeRegistry.playC2S().register(ImportPresetPayload.ID, ImportPresetPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ImportPresetListPayload.ID, ImportPresetListPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(WandSelectPayload.ID, WandSelectPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ToggleLockedSlotPayload.ID, ToggleLockedSlotPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(ToggleLockedSlotPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                var player = context.player();
                if (player == null) return;

                int idx = payload.playerInventoryIndex();
                if (idx < 0 || idx >= player.method_31548().method_5439()) return;

                ChestSortState state = ChestSortState.get(context.server());
                state.toggleLockedSlot(player.method_5845(), idx);
                sendLockedSlotsTo(player);
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(WandSelectPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                var player = context.player();
                if (player == null) return;

                ChestSortState state = ChestSortState.get(context.server());
                String uuid = player.method_5845();
                String wandItemId = state.getWandItemId(uuid);
                if (wandItemId == null || wandItemId.isEmpty()) return;

                String dimId = payload.dimensionId() == null ? "" : payload.dimensionId().trim();
                if (dimId.isEmpty()) return;

                byte which = payload.which();
                if (which == 1) {
                    state.setWandPos1(uuid, dimId, payload.posLong());
                } else if (which == 2) {
                    state.setWandPos2(uuid, dimId, payload.posLong());
                } else {
                    return;
                }

                var p1 = state.getWandPos1(uuid);
                var p2 = state.getWandPos2(uuid);
                long blockCount = 0L;
                int containerCount = 0;

                if (p1 != null && p2 != null && p1.dimensionId().equals(p2.dimensionId())) {
                    class_2960 dimIdentifier = class_2960.method_12829(p1.dimensionId());
                    class_3218 world = dimIdentifier == null ? null : context.server().method_3847(net.minecraft.class_5321.method_29179(net.minecraft.class_7924.field_41223, dimIdentifier));
                    if (world != null) {
                        blockCount = WandSelectionUtil.volume(p1.pos(), p2.pos());
                        containerCount = WandSelectionUtil.findLoadedContainerCanonicalPosLongsInBox(world, p1.pos(), p2.pos()).size();
                    }
                }

                // Actionbar feedback
                String label = which == 1 ? "pos1" : "pos2";
                var setPos = which == 1 ? state.getWandPos1(uuid) : state.getWandPos2(uuid);
                if (setPos != null) {
                    class_2338 bp = setPos.pos();
                    net.minecraft.class_5250 msg = net.minecraft.class_2561.method_43470("[CS] ").method_27692(net.minecraft.class_124.field_1065)
                        .method_10852(net.minecraft.class_2561.method_43470("Wand " + label + ": ").method_27692(net.minecraft.class_124.field_1080))
                        .method_10852(net.minecraft.class_2561.method_43470(bp.method_10263() + " " + bp.method_10264() + " " + bp.method_10260()).method_27692(net.minecraft.class_124.field_1054));
                    if (blockCount > 0L) {
                        msg = msg.method_10852(net.minecraft.class_2561.method_43470("  Area: ").method_27692(net.minecraft.class_124.field_1080))
                            .method_10852(net.minecraft.class_2561.method_43470(String.valueOf(blockCount)).method_27692(net.minecraft.class_124.field_1054))
                            .method_10852(net.minecraft.class_2561.method_43470(" blocks, ").method_27692(net.minecraft.class_124.field_1080))
                            .method_10852(net.minecraft.class_2561.method_43470(String.valueOf(containerCount)).method_27692(net.minecraft.class_124.field_1054))
                            .method_10852(net.minecraft.class_2561.method_43470(" containers").method_27692(net.minecraft.class_124.field_1080));
                    }
                    player.method_7353(msg, true);
                }

                ServerPlayNetworking.send(player, new WandSelectionPayload(
                    wandItemId,
                    p1 != null,
                    p1 == null ? "" : p1.dimensionId(),
                    p1 == null ? 0L : p1.posLong(),
                    p2 != null,
                    p2 == null ? "" : p2.dimensionId(),
                    p2 == null ? 0L : p2.posLong(),
                    blockCount,
                    containerCount
                ));
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(SetFilterPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                ChestSortState state = ChestSortState.get(context.server());

                class_2960 dimIdentifier = class_2960.method_12829(payload.dimensionId());
                class_3218 world = dimIdentifier == null ? null : context.server().method_3847(net.minecraft.class_5321.method_29179(net.minecraft.class_7924.field_41223, dimIdentifier));
                if (world == null) {
                    state.setFilter(payload.dimensionId(), payload.posLong(), payload.filterItems());
                    return;
                }

                class_2338 pos = class_2338.method_10092(payload.posLong());
                class_2586 be = world.method_8321(pos);
                if (be == null) {
                    state.setFilter(payload.dimensionId(), payload.posLong(), payload.filterItems());
                    return;
                }

                long canonicalPosLong = ContainerCanonicalizer.canonicalize(world, pos, be).posLong();
                state.setFilter(payload.dimensionId(), canonicalPosLong, payload.filterItems());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(SetFilterV2Payload.ID, (payload, context) -> {
            context.server().execute(() -> {
                ChestSortState state = ChestSortState.get(context.server());

                class_2960 dimIdentifier = class_2960.method_12829(payload.dimensionId());
                class_3218 world = dimIdentifier == null ? null : context.server().method_3847(net.minecraft.class_5321.method_29179(net.minecraft.class_7924.field_41223, dimIdentifier));
                if (world == null) {
                    state.setFilterSpec(payload.dimensionId(), payload.posLong(), payload.filter());
                    return;
                }

                class_2338 pos = class_2338.method_10092(payload.posLong());
                class_2586 be = world.method_8321(pos);
                if (be == null) {
                    state.setFilterSpec(payload.dimensionId(), payload.posLong(), payload.filter());
                    return;
                }

                long canonicalPosLong = ContainerCanonicalizer.canonicalize(world, pos, be).posLong();
                state.setFilterSpec(payload.dimensionId(), canonicalPosLong, payload.filter());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(SetContainerFiltersPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                ChestSortState state = ChestSortState.get(context.server());

                class_2960 dimIdentifier = class_2960.method_12829(payload.dimensionId());
                class_3218 world = dimIdentifier == null ? null : context.server().method_3847(net.minecraft.class_5321.method_29179(net.minecraft.class_7924.field_41223, dimIdentifier));
                if (world == null) {
                    state.setFilterSpec(payload.dimensionId(), payload.posLong(), payload.whitelist());
                    state.setBlacklistSpec(payload.dimensionId(), payload.posLong(), payload.blacklist());
                    state.setWhitelistPriority(payload.dimensionId(), payload.posLong(), payload.whitelistPriority());
                    return;
                }

                class_2338 pos = class_2338.method_10092(payload.posLong());
                class_2586 be = world.method_8321(pos);
                if (be == null) {
                    state.setFilterSpec(payload.dimensionId(), payload.posLong(), payload.whitelist());
                    state.setBlacklistSpec(payload.dimensionId(), payload.posLong(), payload.blacklist());
                    state.setWhitelistPriority(payload.dimensionId(), payload.posLong(), payload.whitelistPriority());
                    return;
                }

                long canonicalPosLong = ContainerCanonicalizer.canonicalize(world, pos, be).posLong();
                state.setFilterSpec(payload.dimensionId(), canonicalPosLong, payload.whitelist());
                state.setBlacklistSpec(payload.dimensionId(), canonicalPosLong, payload.blacklist());
                state.setWhitelistPriority(payload.dimensionId(), canonicalPosLong, payload.whitelistPriority());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(SortRequestPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                var player = context.player();
                if (player == null) return;

                class_2960 dimIdentifier = class_2960.method_12829(payload.dimensionId());
                if (dimIdentifier == null) return;

                // Only allow sorting in the player's current world.
                class_3218 world = player.method_51469();
                if (!world.method_27983().method_29177().equals(dimIdentifier)) return;

                class_2338 pos = class_2338.method_10092(payload.posLong());
                if (player.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5) > 64.0) return;

                class_2586 be = world.method_8321(pos);
                if (!(be instanceof class_2595) && !(be instanceof class_3719)) return;

                long canonicalPosLong = ContainerCanonicalizer.canonicalize(world, pos, be).posLong();

                // Sort into the currently opened container inventory.
                if (!(player.field_7512 instanceof net.minecraft.class_1707 handler)) return;
                class_1263 containerInv = handler.method_7629();

                ChestSortState state = ChestSortState.get(context.server());
                ContainerFilterSpec filter = state.getFilterSpec(payload.dimensionId(), canonicalPosLong);
                if (filter == null || filter.isEmpty()) {
                    // Still report that nothing was moved.
                    ServerPlayNetworking.send(player, new SortResultPayload(
                        payload.dimensionId(),
                        canonicalPosLong,
                        SortResultPayload.KIND_SORT,
                        state.getAutosortMode(player.method_5845()),
                        false,
                        0L,
                        0,
                        List.of()
                    ));
                    return;
                }

                ContainerFilterSpec effective = state.resolveWithAppliedPresets(filter);
                if (effective == null || effective.isEmpty()) {
                    ServerPlayNetworking.send(player, new SortResultPayload(
                        payload.dimensionId(),
                        canonicalPosLong,
                        SortResultPayload.KIND_SORT,
                        state.getAutosortMode(player.method_5845()),
                        filter.autosort(),
                        0L,
                        0,
                        List.of()
                    ));
                    return;
                }

                ContainerFilterSpec blacklist = state.getBlacklistSpec(payload.dimensionId(), canonicalPosLong);
                ContainerFilterSpec effectiveBlacklist = blacklist == null ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : state.resolveBlacklistWithAppliedPresets(blacklist);
                boolean whitelistPriority = state.whitelistPriority(payload.dimensionId(), canonicalPosLong);

                SortOperationResult result = sortMatchingIntoDetailed(
                    state,
                    player.method_5845(),
                    payload.dimensionId(),
                    canonicalPosLong,
                    player.method_31548(),
                    containerInv,
                    filter,
                    effective,
                    blacklist,
                    effectiveBlacklist,
                    whitelistPriority
                );
                if (result.movedTotal > 0) {
                    player.field_7512.method_7623();
                    // Update snapshot for this container after sorting.
                    state.updateFromBlockEntity(world, () -> canonicalPosLong, containerInv, be instanceof class_2595 ? "chest" : "barrel");
                }

                ServerPlayNetworking.send(player, new SortResultPayload(
                    payload.dimensionId(),
                    canonicalPosLong,
                    SortResultPayload.KIND_SORT,
                    state.getAutosortMode(player.method_5845()),
                    filter.autosort(),
                    result.undoId,
                    result.movedTotal,
                    result.lines
                ));
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(OrganizeRequestPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                var player = context.player();
                if (player == null) return;

                class_2960 dimIdentifier = class_2960.method_12829(payload.dimensionId());
                if (dimIdentifier == null) return;

                // Only allow organizing in the player's current world.
                class_3218 world = player.method_51469();
                if (!world.method_27983().method_29177().equals(dimIdentifier)) return;

                class_2338 pos = class_2338.method_10092(payload.posLong());
                if (player.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5) > 64.0) return;

                class_2586 be = world.method_8321(pos);
                if (!(be instanceof class_2595) && !(be instanceof class_3719)) return;

                long canonicalPosLong = ContainerCanonicalizer.canonicalize(world, pos, be).posLong();

                if (!(player.field_7512 instanceof net.minecraft.class_1707 handler)) return;
                class_1263 containerInv = handler.method_7629();

                ChestSortState state = ChestSortState.get(context.server());

                List<class_1799> playerSnap = snapshot(player.method_31548());

                List<class_1799> before = snapshot(containerInv);
                organizeContainer(containerInv);
                List<class_1799> after = snapshot(containerInv);

                int changedSlots = countChangedSlots(before, after);

                long undoId = 0L;
                List<SortResultPayload.SortLine> lines = summarizeContainer(after);

                if (changedSlots > 0) {
                    undoId = state.nextUndoId(player.method_5845());
                    // Reuse the undo mechanism: snapshot player/container before and after.
                    state.setLastSortUndo(player.method_5845(), new ChestSortState.SortUndoTransaction(
                        payload.dimensionId(),
                        canonicalPosLong,
                        undoId,
                        changedSlots,
                        lines,
                        playerSnap,
                        before,
                        playerSnap,
                        after
                    ));

                    player.field_7512.method_7623();
                    state.updateFromBlockEntity(world, () -> canonicalPosLong, containerInv, be instanceof class_2595 ? "chest" : "barrel");
                }

                ServerPlayNetworking.send(player, new SortResultPayload(
                    payload.dimensionId(),
                    canonicalPosLong,
                    SortResultPayload.KIND_ORGANIZE,
                    state.getAutosortMode(player.method_5845()),
                    false,
                    undoId,
                    changedSlots,
                    lines
                ));
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(UndoSortPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                var player = context.player();
                if (player == null) return;

                class_2960 dimIdentifier = class_2960.method_12829(payload.dimensionId());
                if (dimIdentifier == null) return;

                class_3218 world = player.method_51469();
                if (!world.method_27983().method_29177().equals(dimIdentifier)) return;

                class_2338 pos = class_2338.method_10092(payload.posLong());
                if (player.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5) > 64.0) return;

                class_2586 be = world.method_8321(pos);
                if (!(be instanceof class_2595) && !(be instanceof class_3719)) return;

                long canonicalPosLong = ContainerCanonicalizer.canonicalize(world, pos, be).posLong();

                if (!(player.field_7512 instanceof net.minecraft.class_1707 handler)) return;
                class_1263 containerInv = handler.method_7629();

                ChestSortState state = ChestSortState.get(context.server());
                ChestSortState.SortUndoTransaction tx = state.getLastSortUndo(player.method_5845());
                if (tx == null) return;
                if (tx.undoId() != payload.undoId()) return;
                if (!payload.dimensionId().equals(tx.dimensionId())) return;
                if (tx.posLong() != canonicalPosLong) return;

                restoreSnapshot(player.method_31548(), tx.playerBefore());
                restoreSnapshot(containerInv, tx.containerBefore());
                player.field_7512.method_7623();
                state.clearLastSortUndo(player.method_5845());
                state.updateFromBlockEntity(world, () -> canonicalPosLong, containerInv, be instanceof class_2595 ? "chest" : "barrel");

                ServerPlayNetworking.send(player, new SortResultPayload(
                    payload.dimensionId(),
                    canonicalPosLong,
                    SortResultPayload.KIND_UNDO,
                    state.getAutosortMode(player.method_5845()),
                    false,
                    0L,
                    tx.movedTotal(),
                    tx.lines()
                ));
            });
        });
        ServerPlayNetworking.registerGlobalReceiver(SetPresetPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                var player = context.player();
                if (player == null) return;

                String name = payload.name() == null ? "" : payload.name().trim();
                if (name.isEmpty()) return;

                ChestSortState state = ChestSortState.get(context.server());
                state.setPreset(name, payload.spec());
                broadcastPresets(context.server());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(SetPresetV2Payload.ID, (payload, context) -> {
            context.server().execute(() -> {
                var player = context.player();
                if (player == null) return;

                String name = payload.name() == null ? "" : payload.name().trim();
                if (name.isEmpty()) return;

                ChestSortState state = ChestSortState.get(context.server());
                state.setPreset(name, payload.whitelist(), payload.blacklist());
                broadcastPresets(context.server());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(ImportPresetPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                var player = context.player();
                if (player == null) return;

                ChestSortState state = ChestSortState.get(context.server());

                // Allow importing either a single named preset or a presetList containing multiple presets.
                try {
                    var list = Cs2StringCodec.decodePresetList(payload.data());
                    var whitelists = list == null ? null : list.whitelists();
                    var blacklists = list == null ? null : list.blacklists();
                    if (whitelists == null || whitelists.isEmpty()) {
                        player.method_7353(net.minecraft.class_2561.method_43470("[CS] Invalid preset import: empty presetList").method_27692(net.minecraft.class_124.field_1061), false);
                        return;
                    }

                    int imported = 0;
                    String firstImportedName = "";

                    for (var e : whitelists.entrySet()) {
                        if (e == null) continue;
                        String desired = e.getKey() == null ? "" : e.getKey().trim();
                        if (desired.isEmpty()) continue;

                        String actual = chestsort$uniquePresetName(state, desired);
                        ContainerFilterSpec wl = e.getValue();
                        ContainerFilterSpec bl = (blacklists == null) ? null : blacklists.get(desired);
                        if ((wl == null || wl.isEmpty()) && (bl == null || bl.isEmpty())) continue;
                        state.setPreset(actual,
                            wl == null ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : wl,
                            bl == null ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : bl);
                        if (imported == 0) firstImportedName = actual;
                        imported++;
                    }

                    if (imported <= 0) {
                        player.method_7353(net.minecraft.class_2561.method_43470("[CS] Invalid preset import: empty presetList").method_27692(net.minecraft.class_124.field_1061), false);
                        return;
                    }

                    broadcastPresets(context.server());
                    sendPresetsTo(player);

                    player.method_7353(net.minecraft.class_2561.method_43470("[CS] Imported " + imported + " preset" + (imported == 1 ? "" : "s") + ".").method_27692(net.minecraft.class_124.field_1060), false);
                    if (!firstImportedName.isEmpty()) {
                        ServerPlayNetworking.send(player, new OpenPresetUiPayload(OpenPresetUiPayload.MODE_EDIT, firstImportedName));
                    }
                    return;
                } catch (IllegalArgumentException ignoredNotList) {
                    // Not a presetList, fall through to single preset import.
                }

                Cs2StringCodec.DecodedPresetImport decoded;
                try {
                    decoded = Cs2StringCodec.decodePresetImport(payload.data());
                } catch (IllegalArgumentException e) {
                    player.method_7353(net.minecraft.class_2561.method_43470("[CS] Invalid preset import: " + e.getMessage()).method_27692(net.minecraft.class_124.field_1061), false);
                    return;
                }

                String name = decoded.name() == null ? "" : decoded.name().trim();
                if (name.isEmpty()) {
                    player.method_7353(net.minecraft.class_2561.method_43470("[CS] Invalid preset import: missing preset name").method_27692(net.minecraft.class_124.field_1061), false);
                    return;
                }

                String actual = chestsort$uniquePresetName(state, name);
                ContainerFilterSpec wl = decoded.whitelist();
                ContainerFilterSpec bl = decoded.blacklist();
                if ((wl == null || wl.isEmpty()) && (bl == null || bl.isEmpty())) {
                    player.method_7353(net.minecraft.class_2561.method_43470("[CS] Invalid preset import: empty preset").method_27692(net.minecraft.class_124.field_1061), false);
                    return;
                }

                state.setPreset(actual,
                    wl == null ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : wl,
                    bl == null ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : bl);
                broadcastPresets(context.server());

                sendPresetsTo(player);
                player.method_7353(net.minecraft.class_2561.method_43470("[CS] Imported preset: " + actual).method_27692(net.minecraft.class_124.field_1060), false);
                ServerPlayNetworking.send(player, new OpenPresetUiPayload(OpenPresetUiPayload.MODE_EDIT, actual));
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(ImportPresetListPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                var player = context.player();
                if (player == null) return;

                ChestSortState state = ChestSortState.get(context.server());
                List<String> names = payload.names() == null ? List.of() : payload.names();
                List<ContainerFilterSpec> specs = payload.specs() == null ? List.of() : payload.specs();
                int count = Math.min(names.size(), specs.size());
                if (count <= 0) {
                    player.method_7353(net.minecraft.class_2561.method_43470("[CS] Invalid preset import: nothing selected").method_27692(net.minecraft.class_124.field_1061), false);
                    return;
                }

                int imported = 0;
                String firstImportedName = "";
                for (int i = 0; i < count; i++) {
                    String desired = names.get(i) == null ? "" : names.get(i).trim();
                    if (desired.isEmpty()) continue;
                    ContainerFilterSpec spec = specs.get(i);
                    if (spec == null || spec.isEmpty()) continue;

                    String actual = chestsort$uniquePresetName(state, desired);
                    state.setPreset(actual, spec);
                    if (imported == 0) firstImportedName = actual;
                    imported++;
                }

                if (imported <= 0) {
                    player.method_7353(net.minecraft.class_2561.method_43470("[CS] Invalid preset import: nothing selected").method_27692(net.minecraft.class_124.field_1061), false);
                    return;
                }

                broadcastPresets(context.server());
                sendPresetsTo(player);

                player.method_7353(net.minecraft.class_2561.method_43470("[CS] Imported " + imported + " preset" + (imported == 1 ? "" : "s") + ".").method_27692(net.minecraft.class_124.field_1060), false);
                if (!firstImportedName.isEmpty()) {
                    ServerPlayNetworking.send(player, new OpenPresetUiPayload(OpenPresetUiPayload.MODE_EDIT, firstImportedName));
                }
            });
        });
    }

    private static String chestsort$uniquePresetName(ChestSortState state, String desiredName) {
        String base = desiredName == null ? "" : desiredName.trim();
        if (base.isEmpty()) return base;
        if (state == null) return base;
        if (!state.hasPreset(base)) return base;

        for (int i = 2; i < 10_000; i++) {
            String n = base + " " + i;
            if (!state.hasPreset(n)) return n;
        }
        return base + " " + System.currentTimeMillis();
    }

    public static SortOperationResult sortMatchingIntoDetailed(
        ChestSortState state,
        String playerUuid,
        String dimId,
        long posLong,
        net.minecraft.class_1661 playerInv,
        class_1263 containerInv,
        ContainerFilterSpec baseWhitelist,
        ContainerFilterSpec effectiveWhitelist,
        ContainerFilterSpec baseBlacklist,
        ContainerFilterSpec effectiveBlacklist,
        boolean whitelistPriority
    ) {
        List<class_1799> playerBefore = snapshot(playerInv);
        List<class_1799> containerBefore = snapshot(containerInv);

        SortDetailAccumulator detail = new SortDetailAccumulator();
        int moved = sortMatchingInto(playerInv, containerInv, effectiveWhitelist, effectiveBlacklist, whitelistPriority, detail, baseWhitelist, state, playerUuid);

        List<class_1799> playerAfter = snapshot(playerInv);
        List<class_1799> containerAfter = snapshot(containerInv);

        List<SortResultPayload.SortLine> lines = detail.toLines();

        long undoId = 0L;
        if (moved > 0 && state != null && playerUuid != null && !playerUuid.isEmpty()) {
            undoId = state.nextUndoId(playerUuid);
            state.setLastSortUndo(playerUuid, new ChestSortState.SortUndoTransaction(
                dimId == null ? "" : dimId,
                posLong,
                undoId,
                moved,
                lines,
                playerBefore,
                containerBefore,
                playerAfter,
                containerAfter
            ));
        }

        return new SortOperationResult(undoId, moved, lines);
    }

    public record SortOperationResult(long undoId, int movedTotal, List<SortResultPayload.SortLine> lines) {
    }

    private static int sortMatchingInto(
        net.minecraft.class_1661 playerInv,
        class_1263 containerInv,
        ContainerFilterSpec whitelist,
        ContainerFilterSpec blacklist,
        boolean whitelistPriority,
        SortDetailAccumulator detail,
        ContainerFilterSpec baseWhitelist,
        ChestSortState state,
        String playerUuid
    ) {
        ContainerFilterSpec w = whitelist == null ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : whitelist;
        ContainerFilterSpec b = blacklist == null ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : blacklist;

        Set<String> allowedItemIds = new HashSet<>(w.items() == null ? List.of() : w.items());
        List<TagFilterRuntime> tagFilters = compileTagFilters(w.tags());

        Set<String> blockedItemIds = new HashSet<>(b.items() == null ? List.of() : b.items());
        List<TagFilterRuntime> blacklistTagFilters = compileTagFilters(b.tags());

        int moved = 0;

        for (int i = 0; i < playerInv.method_5439(); i++) {
            if (state != null && playerUuid != null && !playerUuid.isEmpty() && state.isSlotLocked(playerUuid, i)) {
                continue;
            }
            class_1799 stack = playerInv.method_5438(i);
            if (stack.method_7960()) continue;

            String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();

            if (state != null && playerUuid != null && !playerUuid.isEmpty() && state.isItemBlacklisted(playerUuid, itemId)) {
                continue;
            }

            boolean allowed = allowedItemIds.contains(itemId);
            if (!allowed) {
                for (TagFilterRuntime tf : tagFilters) {
                    if (tf.matches(stack, itemId)) {
                        allowed = true;
                        break;
                    }
                }
            }

            if (!allowed) continue;

            boolean blocked = blockedItemIds.contains(itemId);
            if (!blocked) {
                for (TagFilterRuntime tf : blacklistTagFilters) {
                    if (tf.matches(stack, itemId)) {
                        blocked = true;
                        break;
                    }
                }
            }

            if (blocked && !whitelistPriority) continue;

            int before = stack.method_7947();
            class_1799 remainder = insertInto(containerInv, stack);
            playerInv.method_5447(i, remainder);
            int movedHere = (before - remainder.method_7947());
            moved += movedHere;

            if (detail != null && movedHere > 0) {
                detail.addMoved(itemId, movedHere, explainReasons(stack, itemId, baseWhitelist, state));
            }
        }

        return moved;
    }

    private static List<String> explainReasons(class_1799 stack, String itemId, ContainerFilterSpec baseFilter, ChestSortState state) {
        ArrayList<String> out = new ArrayList<>();
        if (baseFilter == null) {
            out.add("Matched filter");
            return out;
        }

        ContainerFilterSpec base = baseFilter.normalized();
        if (base.items() != null && base.items().contains(itemId)) {
            out.add("Matched item filter");
        }
        List<TagFilterRuntime> baseTags = compileTagFilters(base.tags());
        for (TagFilterRuntime tf : baseTags) {
            if (tf.matches(stack, itemId)) {
                out.add("Matched tag filter #" + tf.tagKey().comp_327());
            }
        }

        if (state != null && base.presets() != null) {
            for (String presetName : base.presets()) {
                if (presetName == null || presetName.isEmpty()) continue;
                ContainerFilterSpec preset = state.getPreset(presetName);
                if (preset == null) continue;
                ContainerFilterSpec p = preset.normalized();
                if (p.items() != null && p.items().contains(itemId)) {
                    out.add("Matched preset \"" + presetName + "\" containing item filter");
                }
                List<TagFilterRuntime> presetTags = compileTagFilters(p.tags());
                for (TagFilterRuntime tf : presetTags) {
                    if (tf.matches(stack, itemId)) {
                        out.add("Matched preset \"" + presetName + "\" containing tag filter #" + tf.tagKey().comp_327());
                    }
                }
            }
        }

        if (out.isEmpty()) {
            out.add("Matched filter");
        }
        return out;
    }

    private static List<class_1799> snapshot(class_1263 inv) {
        ArrayList<class_1799> out = new ArrayList<>(inv.method_5439());
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 s = inv.method_5438(i);
            out.add(s == null ? class_1799.field_8037 : s.method_7972());
        }
        return out;
    }

    private static void restoreSnapshot(class_1263 inv, List<class_1799> snap) {
        if (snap == null) return;
        int n = Math.min(inv.method_5439(), snap.size());
        for (int i = 0; i < n; i++) {
            class_1799 s = snap.get(i);
            inv.method_5447(i, s == null ? class_1799.field_8037 : s.method_7972());
        }
        inv.method_5431();
    }

    private static final class SortDetailAccumulator {
        private final java.util.LinkedHashMap<String, Integer> movedByItem = new java.util.LinkedHashMap<>();
        private final java.util.HashMap<String, List<String>> reasonsByItem = new java.util.HashMap<>();

        void addMoved(String itemId, int count, List<String> reasons) {
            if (itemId == null || itemId.isEmpty()) return;
            movedByItem.merge(itemId, count, Integer::sum);
            if (reasons != null && !reasons.isEmpty()) {
                reasonsByItem.putIfAbsent(itemId, reasons);
            }
        }

        List<SortResultPayload.SortLine> toLines() {
            ArrayList<SortResultPayload.SortLine> out = new ArrayList<>(movedByItem.size());
            for (var e : movedByItem.entrySet()) {
                String itemId = e.getKey();
                int count = e.getValue();
                List<String> reasons = reasonsByItem.getOrDefault(itemId, List.of());
                out.add(new SortResultPayload.SortLine(itemId, count, reasons));
            }
            // Sort biggest-first to make the notification more useful.
            out.sort((a, b) -> Integer.compare(b.count(), a.count()));
            return out;
        }
    }

    private static int countChangedSlots(List<class_1799> before, List<class_1799> after) {
        if (before == null || after == null) return 0;
        int n = Math.min(before.size(), after.size());
        int changed = 0;
        for (int i = 0; i < n; i++) {
            class_1799 a = before.get(i);
            class_1799 b = after.get(i);
            if (a == null) a = class_1799.field_8037;
            if (b == null) b = class_1799.field_8037;
            if (!class_1799.method_31577(a, b) || a.method_7947() != b.method_7947()) {
                changed++;
            }
        }
        return changed;
    }

    private static void organizeContainer(class_1263 containerInv) {
        if (containerInv == null) return;

        ArrayList<class_1799> stacks = new ArrayList<>();
        for (int i = 0; i < containerInv.method_5439(); i++) {
            class_1799 s = containerInv.method_5438(i);
            if (s == null || s.method_7960()) continue;
            stacks.add(s.method_7972());
        }

        // Group by combine-compatibility. Container sizes are small enough for O(n^2).
        ArrayList<class_1799> protos = new ArrayList<>();
        ArrayList<Integer> totals = new ArrayList<>();

        for (class_1799 s : stacks) {
            boolean merged = false;
            for (int g = 0; g < protos.size(); g++) {
                if (class_1799.method_31577(protos.get(g), s)) {
                    totals.set(g, totals.get(g) + s.method_7947());
                    merged = true;
                    break;
                }
            }
            if (!merged) {
                class_1799 p = s.method_7972();
                p.method_7939(1);
                protos.add(p);
                totals.add(s.method_7947());
            }
        }

        ArrayList<class_1799> packed = new ArrayList<>();
        for (int i = 0; i < protos.size(); i++) {
            class_1799 proto = protos.get(i);
            int total = totals.get(i);
            int max = Math.min(proto.method_7914(), containerInv.method_5444());
            int remaining = total;
            while (remaining > 0) {
                int take = Math.min(max, remaining);
                class_1799 out = proto.method_7972();
                out.method_7939(take);
                packed.add(out);
                remaining -= take;
            }
        }

        // Write back sequentially.
        int slot = 0;
        for (; slot < containerInv.method_5439() && slot < packed.size(); slot++) {
            containerInv.method_5447(slot, packed.get(slot));
        }
        for (; slot < containerInv.method_5439(); slot++) {
            containerInv.method_5447(slot, class_1799.field_8037);
        }
        containerInv.method_5431();
    }

    private static List<SortResultPayload.SortLine> summarizeContainer(List<class_1799> after) {
        if (after == null || after.isEmpty()) return List.of();

        java.util.LinkedHashMap<String, Integer> totals = new java.util.LinkedHashMap<>();
        for (class_1799 s : after) {
            if (s == null || s.method_7960()) continue;
            String id = class_7923.field_41178.method_10221(s.method_7909()).toString();
            totals.merge(id, s.method_7947(), Integer::sum);
        }

        ArrayList<SortResultPayload.SortLine> out = new ArrayList<>(totals.size());
        for (var e : totals.entrySet()) {
            out.add(new SortResultPayload.SortLine(e.getKey(), e.getValue(), List.of("Grouped in container")));
        }
        out.sort((a, b) -> Integer.compare(b.count(), a.count()));
        return out;
    }

    public static void sendPresetsTo(net.minecraft.class_3222 player) {
        if (player == null) return;
        ChestSortState state = ChestSortState.get(((net.minecraft.class_3218) player.method_51469()).method_8503());

        Map<String, ContainerFilterSpec> presets = state.getPresets();
        Map<String, ContainerFilterSpec> presetBlacklists = state.getPresetBlacklists();
        ArrayList<String> names = new ArrayList<>(presets.size());
        ArrayList<ContainerFilterSpec> specs = new ArrayList<>(presets.size());
        ArrayList<ContainerFilterSpec> blSpecs = new ArrayList<>(presets.size());
        for (var e : presets.entrySet()) {
            String name = e.getKey();
            if (name == null || name.trim().isEmpty()) continue;
            names.add(name);
            specs.add(e.getValue() == null ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : e.getValue());

            ContainerFilterSpec bl = presetBlacklists.get(name);
            blSpecs.add(bl == null ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : bl);
        }

        // Prefer v2 (whitelist+blacklist), but keep v1 for compatibility.
        ServerPlayNetworking.send(player, new PresetSyncV2Payload(names, specs, blSpecs));
        ServerPlayNetworking.send(player, new PresetSyncPayload(names, specs));
    }

    public static void sendLockedSlotsTo(net.minecraft.class_3222 player) {
        if (player == null) return;
        ChestSortState state = ChestSortState.get(((net.minecraft.class_3218) player.method_51469()).method_8503());
        List<Integer> locked = state.getLockedSlots(player.method_5845());
        ServerPlayNetworking.send(player, new LockedSlotsSyncPayload(locked));
    }

    public static void broadcastPresets(net.minecraft.server.MinecraftServer server) {
        if (server == null) return;
        for (var player : server.method_3760().method_14571()) {
            sendPresetsTo(player);
        }
    }

    public static int sortMatchingInto(net.minecraft.class_1661 playerInv, class_1263 containerInv, ContainerFilterSpec filter) {
        Set<String> allowedItemIds = new HashSet<>(filter.items() == null ? List.of() : filter.items());

        List<TagFilterRuntime> tagFilters = compileTagFilters(filter.tags());

        int moved = 0;

        for (int i = 0; i < playerInv.method_5439(); i++) {
            class_1799 stack = playerInv.method_5438(i);
            if (stack.method_7960()) continue;

            String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();

            boolean allowed = allowedItemIds.contains(itemId);
            if (!allowed) {
                for (TagFilterRuntime tf : tagFilters) {
                    if (tf.matches(stack, itemId)) {
                        allowed = true;
                        break;
                    }
                }
            }

            if (!allowed) continue;

            int before = stack.method_7947();
            class_1799 remainder = insertInto(containerInv, stack);
            playerInv.method_5447(i, remainder);
            moved += (before - remainder.method_7947());
        }

        return moved;
    }

    private static List<TagFilterRuntime> compileTagFilters(List<TagFilterSpec> tags) {
        if (tags == null || tags.isEmpty()) return List.of();
        ArrayList<TagFilterRuntime> out = new ArrayList<>(tags.size());
        for (TagFilterSpec tag : tags) {
            if (tag == null) continue;
            String raw = tag.tagId();
            if (raw == null) continue;
            String idStr = raw.startsWith("#") ? raw.substring(1) : raw;
            class_2960 id = class_2960.method_12829(idStr);
            if (id == null) continue;
            class_6862<net.minecraft.class_1792> key = class_6862.method_40092(class_7924.field_41197, id);

            Set<String> exceptions = new HashSet<>();
            if (tag.exceptions() != null) {
                for (String exc : tag.exceptions()) {
                    if (exc == null) continue;
                    String t = exc.trim();
                    if (!t.isEmpty()) exceptions.add(t);
                }
            }
            out.add(new TagFilterRuntime(key, exceptions));
        }
        return out;
    }

    private record TagFilterRuntime(class_6862<net.minecraft.class_1792> tagKey, Set<String> exceptions) {
        boolean matches(class_1799 stack, String itemId) {
            if (exceptions != null && exceptions.contains(itemId)) return false;
            return stack.method_31573(tagKey);
        }
    }

    private static class_1799 insertInto(class_1263 container, class_1799 stack) {
        if (stack.method_7960()) return stack;
        class_1799 remaining = stack.method_7972();

        // First pass: merge into existing stacks.
        for (int i = 0; i < container.method_5439(); i++) {
            class_1799 existing = container.method_5438(i);
            if (existing.method_7960()) continue;
            if (!class_1799.method_31577(existing, remaining)) continue;

            int max = Math.min(existing.method_7914(), container.method_5444());
            int canAdd = max - existing.method_7947();
            if (canAdd <= 0) continue;

            int toMove = Math.min(canAdd, remaining.method_7947());
            existing.method_7933(toMove);
            remaining.method_7934(toMove);
            container.method_5447(i, existing);
            if (remaining.method_7960()) return class_1799.field_8037;
        }

        // Second pass: fill empty slots.
        for (int i = 0; i < container.method_5439(); i++) {
            class_1799 existing = container.method_5438(i);
            if (!existing.method_7960()) continue;

            int max = Math.min(remaining.method_7914(), container.method_5444());
            int toMove = Math.min(max, remaining.method_7947());

            class_1799 placed = remaining.method_7972();
            placed.method_7939(toMove);
            container.method_5447(i, placed);
            remaining.method_7934(toMove);
            if (remaining.method_7960()) return class_1799.field_8037;
        }

        return remaining;
    }
}
