package dev.dromer.chestsort.util;

import net.minecraft.class_1258;
import net.minecraft.class_1263;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_3218;
import net.minecraft.class_3719;
import net.minecraft.class_4732;

/**
 * Resolves a container to a canonical position key so multi-block containers (double chests)
 * share the same stored filter/snapshot regardless of which half was interacted with.
 */
public final class ContainerCanonicalizer {
    private ContainerCanonicalizer() {
    }

    public record Canonicalized(long posLong, class_1263 snapshotInventory, String containerType) {
    }

    public static Canonicalized canonicalize(class_3218 world, class_2338 clickedPos, class_2586 be) {
        if (be instanceof class_2595 chest) {
            return canonicalizeChest(world, clickedPos, chest);
        }
        if (be instanceof class_3719 barrel) {
            return new Canonicalized(clickedPos.method_10063(), barrel, "barrel");
        }
        return new Canonicalized(clickedPos.method_10063(), null, "");
    }

    private static Canonicalized canonicalizeChest(class_3218 world, class_2338 clickedPos, class_2595 chest) {
        var state = chest.method_11010();
        if (!(state.method_26204() instanceof class_2281 chestBlock)) {
            return new Canonicalized(clickedPos.method_10063(), chest, "chest");
        }

        var source = chestBlock.method_24167(state, world, clickedPos, true);
        return source.apply(new class_4732.class_3923<class_2595, Canonicalized>() {
            @Override
            public Canonicalized getFromBoth(class_2595 first, class_2595 second) {
                long p1 = first.method_11016().method_10063();
                long p2 = second.method_11016().method_10063();
                long canonical = Math.min(p1, p2);
                class_1263 inv = new class_1258(first, second);
                return new Canonicalized(canonical, inv, "chest");
            }

            @Override
            public Canonicalized getFrom(class_2595 single) {
                return new Canonicalized(single.method_11016().method_10063(), single, "chest");
            }

            @Override
            public Canonicalized method_24174() {
                return new Canonicalized(clickedPos.method_10063(), chest, "chest");
            }
        });
    }
}
