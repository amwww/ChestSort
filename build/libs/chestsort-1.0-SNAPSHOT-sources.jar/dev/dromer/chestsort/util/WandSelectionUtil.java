package dev.dromer.chestsort.util;

import java.util.LinkedHashSet;
import java.util.Set;
import net.minecraft.class_2338;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_3218;

public final class WandSelectionUtil {
    private WandSelectionUtil() {
    }

    public static long volume(class_2338 a, class_2338 b) {
        if (a == null || b == null) return 0L;
        long dx = (long) Math.abs(a.method_10263() - b.method_10263()) + 1L;
        long dy = (long) Math.abs(a.method_10264() - b.method_10264()) + 1L;
        long dz = (long) Math.abs(a.method_10260() - b.method_10260()) + 1L;
        return dx * dy * dz;
    }

    /** Returns canonical container positions (deduping multi-block containers) for LOADED chunks only. */
    public static Set<Long> findLoadedContainerCanonicalPosLongsInBox(class_3218 world, class_2338 a, class_2338 b) {
        if (world == null || a == null || b == null) return Set.of();

        int minX = Math.min(a.method_10263(), b.method_10263());
        int minY = Math.min(a.method_10264(), b.method_10264());
        int minZ = Math.min(a.method_10260(), b.method_10260());
        int maxX = Math.max(a.method_10263(), b.method_10263());
        int maxY = Math.max(a.method_10264(), b.method_10264());
        int maxZ = Math.max(a.method_10260(), b.method_10260());

        int minChunkX = minX >> 4;
        int maxChunkX = maxX >> 4;
        int minChunkZ = minZ >> 4;
        int maxChunkZ = maxZ >> 4;

        LinkedHashSet<Long> out = new LinkedHashSet<>();
        LinkedHashSet<Long> seenCanonical = new LinkedHashSet<>();

        for (int cx = minChunkX; cx <= maxChunkX; cx++) {
            for (int cz = minChunkZ; cz <= maxChunkZ; cz++) {
                var chunk = world.method_8402(cx, cz, class_2806.field_12803, false);
                if (!(chunk instanceof class_2818 worldChunk)) continue;

                for (var be : worldChunk.method_12214().values()) {
                    if (be == null) continue;
                    class_2338 pos = be.method_11016();
                    if (pos.method_10263() < minX || pos.method_10263() > maxX) continue;
                    if (pos.method_10264() < minY || pos.method_10264() > maxY) continue;
                    if (pos.method_10260() < minZ || pos.method_10260() > maxZ) continue;

                    var canonical = ContainerCanonicalizer.canonicalize(world, pos, be);
                    if (canonical.snapshotInventory() == null) continue;

                    long canonicalPosLong = canonical.posLong();
                    if (!seenCanonical.add(canonicalPosLong)) continue;
                    out.add(canonicalPosLong);
                }
            }
        }

        return Set.copyOf(out);
    }
}
