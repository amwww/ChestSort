package dev.dromer.chestsort.mixin.client;

import dev.dromer.chestsort.client.ClientHighlightState;
import net.minecraft.class_310;
import net.minecraft.class_437;
import dev.dromer.chestsort.client.ClientContainerContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftClientMixin {

    @Inject(method = "setScreen", at = @At("HEAD"))
    private void chestsort$setScreen(class_437 screen, CallbackInfo ci) {
        if (screen == null) {
            ClientHighlightState.clear();
            ClientContainerContext.clear();
            return;
        }

        // Leaving a handled screen should also clear container context.
        if (!(screen instanceof net.minecraft.class_465)) {
            ClientContainerContext.clear();
        }
    }
}
