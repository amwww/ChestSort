package dev.dromer.chestsort.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.dromer.chestsort.data.ChestSortState;
import net.minecraft.class_124;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2846;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_7923;

@Mixin(class_3244.class)
public class ServerPlayNetworkHandlerMixin {

    @Shadow
    public class_3222 player;

    @Inject(method = "onPlayerAction", at = @At("HEAD"), cancellable = true)
    private void chestsort$wandSelectPos1(class_2846 packet, CallbackInfo ci) {
        if (player == null) return;
        if (!(player.method_51469() instanceof class_3218 world)) return;
        if (packet == null) return;
        if (packet.method_12363() != class_2846.class_2847.field_12968) return;

        ChestSortState state = ChestSortState.get(world.method_8503());
        String uuid = player.method_5845();
        String wandItemId = state.getWandItemId(uuid);
        if (wandItemId == null || wandItemId.isEmpty()) return;

        boolean holdingWand = false;
        if (!player.method_6047().method_7960()) {
            String id = String.valueOf(class_7923.field_41178.method_10221(player.method_6047().method_7909()));
            holdingWand = wandItemId.equals(id);
        }
        if (!holdingWand && !player.method_6079().method_7960()) {
            String id = String.valueOf(class_7923.field_41178.method_10221(player.method_6079().method_7909()));
            holdingWand = wandItemId.equals(id);
        }
        if (!holdingWand) return;

        class_2338 pos = packet.method_12362();
        if (pos == null) return;

        String dimId = world.method_27983().method_29177().toString();
        state.setWandPos1(uuid, dimId, pos.method_10063());
        player.method_7353(class_2561.method_43470("[CS] ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470("Wand pos1 set to ").method_27692(class_124.field_1080))
            .method_10852(class_2561.method_43470(pos.method_10263() + " " + pos.method_10264() + " " + pos.method_10260()).method_27692(class_124.field_1054)), false);

        // Prevent breaking blocks while selecting.
        ci.cancel();
    }
}
