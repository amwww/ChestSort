package dev.dromer.chestsort.client.gui;

import dev.dromer.chestsort.client.ClientPresetRegistry;
import dev.dromer.chestsort.filter.ContainerFilterSpec;
import dev.dromer.chestsort.filter.TagFilterSpec;
import dev.dromer.chestsort.net.payload.SetPresetV2Payload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_11908;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

public final class PresetEditorScreen extends class_437 {
    private static final int PANEL_W = 180;
    private static final int PANEL_GAP = 8;
    private static final int PANEL_H = 200;
    private static final int ROW_H = 18;
    private static final int HEADER_H = 16;
    private static final int ACTION_W = 14;
    private static final int ACTION_PAD = 6;

    private final String presetName;

    private static final int TAB_WHITELIST = 0;
    private static final int TAB_BLACKLIST = 1;
    private int chestsort$tab = TAB_WHITELIST;

    private ArrayList<String> editingItems = new ArrayList<>();
    private ArrayList<TagFilterSpec> editingTags = new ArrayList<>();

    private ArrayList<String> chestsort$whitelistItems = new ArrayList<>();
    private ArrayList<TagFilterSpec> chestsort$whitelistTags = new ArrayList<>();
    private ArrayList<String> chestsort$blacklistItems = new ArrayList<>();
    private ArrayList<TagFilterSpec> chestsort$blacklistTags = new ArrayList<>();

    private boolean tagBrowserMode = false;
    private String tagBrowserTagId = "";
    private List<class_1792> tagBrowserItems = List.of();
    private final Map<String, List<class_1792>> tagItemsCache = new HashMap<>();

    private class_342 searchField;
    private class_4185 doneButton;
    private class_4185 cancelButton;

    private ArrayList<class_1792> allItems;

    private volatile List<String> chestsort$allItemTagIds;
    private volatile boolean chestsort$tagIdScanStarted = false;

    private List<class_1792> resultItems = List.of();
    private List<String> resultTagIds = List.of();
    private List<String> resultSubtitles = List.of();
    private int resultsScroll = 0;

    private int leftScroll = 0;

    private int chestsort$getRowsAreaH() {
        // PANEL_H includes the search field and buttons at the top.
        return Math.max(ROW_H, PANEL_H - (24 + 24 + HEADER_H));
    }

    private int getLeftTotalRows() {
        // items header + items + tags header + tags
        return 2 + this.editingItems.size() + this.editingTags.size();
    }

    private int getLeftRowsShown() {
        return Math.max(1, chestsort$getRowsAreaH() / ROW_H);
    }

    private void chestsort$clampLeftScroll() {
        int shown = getLeftRowsShown();
        int max = Math.max(0, getLeftTotalRows() - Math.max(1, shown));
        this.leftScroll = Math.max(0, Math.min(this.leftScroll, max));
    }

    private int chestsort$panelW() {
        // Keep the UI on-screen even at high GUI scales / small windows.
        int maxTotalW = Math.max(0, this.field_22789 - 20);
        int perPanel = (maxTotalW - PANEL_GAP) / 2;
        if (perPanel <= 0) return Math.max(60, this.field_22789 / 2);
        return Math.max(60, Math.min(PANEL_W, perPanel));
    }

    private int chestsort$leftX(int panelW) {
        int totalW = (panelW * 2) + PANEL_GAP;
        int x = (this.field_22789 - totalW) / 2;
        // Keep a small margin so text/buttons don't clip.
        return Math.max(10, x);
    }

    public PresetEditorScreen(String presetName) {
        super(class_2561.method_43470("Edit preset"));
        this.presetName = presetName == null ? "" : presetName.trim();
    }

    @Override
    protected void method_25426() {
        loadPresetSpec();

        this.leftScroll = 0;
        this.resultsScroll = 0;

        int panelW = chestsort$panelW();
        int leftX = chestsort$leftX(panelW);
        int rightX = leftX + panelW + PANEL_GAP;
        int topY = Math.max(10, (this.field_22790 - PANEL_H) / 2);

        this.searchField = new class_342(this.field_22793, rightX + 6, topY + 4, panelW - 12, 16, class_2561.method_43470("Search"));
        this.searchField.method_1880(256);
        this.searchField.method_1863(s -> updateSearchResults());
        this.method_37063(this.searchField);

        this.doneButton = class_4185.method_46430(class_2561.method_43470("Done"), b -> {
            saveToServer();
            class_310.method_1551().method_1507(null);
        }).method_46434(rightX + 6, topY + 24, (panelW - 18) / 2, 20).method_46431();
        this.method_37063(this.doneButton);

        this.cancelButton = class_4185.method_46430(class_2561.method_43470("Cancel"), b -> class_310.method_1551().method_1507(null))
            .method_46434(rightX + 12 + (panelW - 18) / 2, topY + 24, (panelW - 18) / 2, 20)
            .method_46431();
        this.method_37063(this.cancelButton);

        updateSearchResults();
    }

    private void loadPresetSpec() {
        if (this.presetName.isEmpty()) {
            this.chestsort$whitelistItems = new ArrayList<>();
            this.chestsort$whitelistTags = new ArrayList<>();
            this.chestsort$blacklistItems = new ArrayList<>();
            this.chestsort$blacklistTags = new ArrayList<>();
            chestsort$applyTab(TAB_WHITELIST);
            return;
        }

        ContainerFilterSpec wl = ClientPresetRegistry.get(this.presetName);
        ContainerFilterSpec bl = ClientPresetRegistry.getBlacklist(this.presetName);

        ContainerFilterSpec safeWl = (wl == null) ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : wl.normalized();
        ContainerFilterSpec safeBl = (bl == null) ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : bl.normalized();

        this.chestsort$whitelistItems = new ArrayList<>(safeWl.items() == null ? List.of() : safeWl.items());
        this.chestsort$whitelistTags = new ArrayList<>(safeWl.tags() == null ? List.of() : safeWl.tags());
        this.chestsort$blacklistItems = new ArrayList<>(safeBl.items() == null ? List.of() : safeBl.items());
        this.chestsort$blacklistTags = new ArrayList<>(safeBl.tags() == null ? List.of() : safeBl.tags());

        chestsort$applyTab(this.chestsort$tab);

        this.tagBrowserMode = false;
        this.tagBrowserTagId = "";
        this.tagBrowserItems = List.of();
        this.tagItemsCache.clear();
    }

    private void chestsort$applyTab(int tab) {
        this.chestsort$tab = (tab == TAB_BLACKLIST) ? TAB_BLACKLIST : TAB_WHITELIST;
        if (this.chestsort$tab == TAB_BLACKLIST) {
            this.editingItems = this.chestsort$blacklistItems;
            this.editingTags = this.chestsort$blacklistTags;
        } else {
            this.editingItems = this.chestsort$whitelistItems;
            this.editingTags = this.chestsort$whitelistTags;
        }

        this.leftScroll = 0;
        this.resultsScroll = 0;

        if (this.tagBrowserMode) {
            this.tagBrowserMode = false;
            this.tagBrowserTagId = "";
            this.tagBrowserItems = List.of();
        }
        if (this.searchField != null) {
            this.searchField.method_1852("");
        }
        updateSearchResults();
    }

    private void saveToServer() {
        if (this.presetName.isEmpty()) return;

        ContainerFilterSpec wl = new ContainerFilterSpec(
            ContainerFilterSpec.normalizeStrings(this.chestsort$whitelistItems),
            this.chestsort$whitelistTags,
            List.of()
        ).normalized();

        ContainerFilterSpec bl = new ContainerFilterSpec(
            ContainerFilterSpec.normalizeStrings(this.chestsort$blacklistItems),
            this.chestsort$blacklistTags,
            List.of()
        ).normalized();

        ClientPlayNetworking.send(new SetPresetV2Payload(this.presetName, wl, bl));
        ClientPresetRegistry.putLocal(this.presetName, wl);
        ClientPresetRegistry.putLocalBlacklist(this.presetName, bl);
    }

    private void ensureAllItems() {
        if (this.allItems != null) return;
        this.allItems = new ArrayList<>();
        for (class_1792 item : class_7923.field_41178) {
            this.allItems.add(item);
        }
    }

    private void updateSearchResults() {
        ensureAllItems();

        String query = this.searchField == null ? "" : (this.searchField.method_1882() == null ? "" : this.searchField.method_1882().trim().toLowerCase(java.util.Locale.ROOT));

        // If the query matches entries already in the filter, move them to the top so the user can see
        // they are already added (and keep them out of the search results).
        if (!this.tagBrowserMode && !query.isEmpty()) {
            if (query.startsWith("#")) {
                chestsort$bumpMatchingTagsToTop(query);
            } else {
                chestsort$bumpMatchingItemsToTop(query);
            }
        }

        if (this.tagBrowserMode) {
            // Mirror container UI behavior: if the query starts with '#', show tag results (to allow
            // selecting a tag to browse), otherwise search within the items of the currently browsed tag.
            if (!query.isEmpty() && query.startsWith("#")) {
                String norm = ContainerFilterSpec.normalizeTagId(query);
                class_2960 id = parseTagIdentifier(norm);

                chestsort$ensureItemTagIdsScanStarted();

                ArrayList<class_1792> items = new ArrayList<>(16);
                ArrayList<String> tagIds = new ArrayList<>(16);
                ArrayList<String> subtitles = new ArrayList<>(16);

                if (id != null && !hasTag(norm)) {
                    items.add(null);
                    tagIds.add(norm);
                    subtitles.add(norm);
                }

                List<String> allTags = this.chestsort$allItemTagIds;
                if (allTags != null && !allTags.isEmpty()) {
                    String q = norm.toLowerCase(java.util.Locale.ROOT);
                    for (String t : allTags) {
                        if (t == null) continue;
                        String tl = t.toLowerCase(java.util.Locale.ROOT);
                        if (!tl.contains(q)) continue;
                        if (t.equals(norm)) continue;
                        if (hasTag(t)) continue;
                        items.add(null);
                        tagIds.add(t);
                        subtitles.add(t);
                        if (items.size() >= 200) break;
                    }
                }

                this.resultItems = items;
                this.resultTagIds = tagIds;
                this.resultSubtitles = subtitles;
                this.resultsScroll = 0;
                return;
            }

            HashSet<String> exc = new HashSet<>(getExceptionSetForTag(this.tagBrowserTagId));
            ArrayList<class_1792> items = new ArrayList<>(16);
            ArrayList<String> tagIds = new ArrayList<>(16);
            ArrayList<String> subtitles = new ArrayList<>(16);

            for (class_1792 item : this.tagBrowserItems) {
                if (item == null) continue;
                String itemId = String.valueOf(class_7923.field_41178.method_10221(item));
                if (itemId.isEmpty()) continue;
                if (exc.contains(itemId)) continue;

                if (!query.isEmpty()) {
                    String idStr = itemId.toLowerCase(java.util.Locale.ROOT);
                    String nameStr = class_2561.method_43471(item.method_7876()).getString().toLowerCase(java.util.Locale.ROOT);
                    if (!idStr.contains(query) && !nameStr.contains(query)) continue;
                }

                items.add(item);
                tagIds.add("");
                subtitles.add(itemId);
                if (items.size() >= 200) break;
            }

            this.resultItems = items;
            this.resultTagIds = tagIds;
            this.resultSubtitles = subtitles;
            this.resultsScroll = 0;
            return;
        }

        if (query.isEmpty()) {
            this.resultItems = List.of();
            this.resultTagIds = List.of();
            this.resultSubtitles = List.of();
            this.resultsScroll = 0;
            return;
        }

        if (query.startsWith("#")) {
            String norm = ContainerFilterSpec.normalizeTagId(query);
            class_2960 id = parseTagIdentifier(norm);

            // Start tag id scan lazily; results update when the scan completes.
            chestsort$ensureItemTagIdsScanStarted();

            ArrayList<class_1792> items = new ArrayList<>(16);
            ArrayList<String> tagIds = new ArrayList<>(16);
            ArrayList<String> subtitles = new ArrayList<>(16);

            // Always include the typed tag id if it is syntactically valid and not already added.
            if (id != null && !hasTag(norm)) {
                items.add(null);
                tagIds.add(norm);
                subtitles.add(norm);
            }

            // If we have a cached tag list, provide substring suggestions.
            List<String> allTags = this.chestsort$allItemTagIds;
            if (allTags != null && !allTags.isEmpty()) {
                String q = norm.toLowerCase(java.util.Locale.ROOT);
                for (String t : allTags) {
                    if (t == null) continue;
                    String tl = t.toLowerCase(java.util.Locale.ROOT);
                    if (!tl.contains(q)) continue;
                    if (t.equals(norm)) continue;
                    if (hasTag(t)) continue;
                    items.add(null);
                    tagIds.add(t);
                    subtitles.add(t);
                    if (items.size() >= 200) break;
                }
            }

            this.resultItems = items;
            this.resultTagIds = tagIds;
            this.resultSubtitles = subtitles;
            this.resultsScroll = 0;
            return;
        }

        ArrayList<class_1792> items = new ArrayList<>(16);
        ArrayList<String> tagIds = new ArrayList<>(16);
        ArrayList<String> subtitles = new ArrayList<>(16);

        HashSet<String> already = new HashSet<>(this.editingItems);
        for (class_1792 item : this.allItems) {
            class_2960 id = class_7923.field_41178.method_10221(item);
            String idStr = id == null ? "" : id.toString();
            String nameStr = class_2561.method_43471(item.method_7876()).getString().toLowerCase(java.util.Locale.ROOT);

            // Keep already-added entries out of the results.
            if (!idStr.isEmpty() && already.contains(idStr)) continue;

            if (idStr.toLowerCase(java.util.Locale.ROOT).contains(query) || nameStr.contains(query)) {
                items.add(item);
                tagIds.add("");
                subtitles.add(idStr);
                if (items.size() >= 200) break;
            }
        }

        this.resultItems = items;
        this.resultTagIds = tagIds;
        this.resultSubtitles = subtitles;
        this.resultsScroll = 0;
    }

    @Override
    public boolean method_25404(class_11908 keyInput) {
        if (this.searchField != null && this.searchField.method_25404(keyInput)) {
            return true;
        }

        class_310 mc = class_310.method_1551();
        if (keyInput.comp_4795() == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
            if (this.tagBrowserMode) {
                this.tagBrowserMode = false;
                this.tagBrowserTagId = "";
                this.tagBrowserItems = List.of();
                if (this.searchField != null) this.searchField.method_1852("");
                updateSearchResults();
                return true;
            }
            if (mc != null) {
                mc.method_1507(null);
            }
            return true;
        }

        return super.method_25404(keyInput);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int panelW = chestsort$panelW();
        int leftX = chestsort$leftX(panelW);
        int rightX = leftX + panelW + PANEL_GAP;
        int topY = Math.max(10, (this.field_22790 - PANEL_H) / 2);
        int rowsY = topY + 24 + 24 + HEADER_H;
        int rowsAreaH = chestsort$getRowsAreaH();

        boolean overLeft = mouseX >= leftX && mouseX < leftX + panelW && mouseY >= rowsY && mouseY < rowsY + rowsAreaH;
        boolean overRight = mouseX >= rightX && mouseX < rightX + panelW && mouseY >= rowsY && mouseY < rowsY + rowsAreaH;

        if (overLeft) {
            int shown = getLeftRowsShown();
            int max = Math.max(0, getLeftTotalRows() - Math.max(1, shown));
            if (verticalAmount > 0) {
                this.leftScroll = Math.max(0, this.leftScroll - 1);
            } else if (verticalAmount < 0) {
                this.leftScroll = Math.min(max, this.leftScroll + 1);
            }
            return true;
        }

        if (overRight) {
            int resultsShown = getResultsRowsShown();
            int maxResults = Math.max(0, getResultsSize() - Math.max(1, resultsShown));
            if (verticalAmount > 0) {
                this.resultsScroll = Math.max(0, this.resultsScroll - 1);
            } else if (verticalAmount < 0) {
                this.resultsScroll = Math.min(maxResults, this.resultsScroll + 1);
            }
            return true;
        }

        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean method_25402(net.minecraft.class_11909 click, boolean bl) {
        int button = click.method_74245();
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        if (button != 0) return super.method_25402(click, bl);

        int panelW = chestsort$panelW();
        int leftX = chestsort$leftX(panelW);
        int rightX = leftX + panelW + PANEL_GAP;
        int topY = Math.max(10, (this.field_22790 - PANEL_H) / 2);

        // Tab row (left panel)
        int tabY1 = topY + 24 + 24;
        int tabY2 = tabY1 + HEADER_H;
        if (mouseX >= leftX && mouseX < leftX + panelW && mouseY >= tabY1 && mouseY < tabY2) {
            int half = panelW / 2;
            if (mouseX < leftX + half) {
                if (this.chestsort$tab != TAB_WHITELIST) {
                    chestsort$applyTab(TAB_WHITELIST);
                }
                return true;
            } else {
                if (this.chestsort$tab != TAB_BLACKLIST) {
                    chestsort$applyTab(TAB_BLACKLIST);
                }
                return true;
            }
        }

        int actionX1Left = (leftX + panelW) - ACTION_PAD - ACTION_W;
        int actionX2Left = (leftX + panelW) - ACTION_PAD;

        // Left rows: items header + items + tags header + tags
        int rowY = topY + 24 + 24 + HEADER_H;
        int rowsAreaH = chestsort$getRowsAreaH();
        int visibleRowIndex = (int) ((mouseY - rowY) / ROW_H);
        if (mouseX >= leftX && mouseX < leftX + panelW && mouseY >= rowY && mouseY < rowY + rowsAreaH) {
            chestsort$clampLeftScroll();
            int rowIndex = this.leftScroll + visibleRowIndex;
            int kind = getLeftRowKind(rowIndex);
            int idx = getLeftRowIndex(rowIndex);

            if (kind == 1) {
                // item
                if (mouseX >= actionX1Left && mouseX < actionX2Left && idx >= 0 && idx < this.editingItems.size()) {
                    this.editingItems.remove(idx);
                    chestsort$clampLeftScroll();
                    return true;
                }
            } else if (kind == 3) {
                // tag
                if (idx >= 0 && idx < this.editingTags.size()) {
                    if (mouseX >= actionX1Left && mouseX < actionX2Left) {
                        this.editingTags.remove(idx);
                        if (this.tagBrowserMode) {
                            this.tagBrowserMode = false;
                            this.tagBrowserTagId = "";
                            this.tagBrowserItems = List.of();
                            if (this.searchField != null) this.searchField.method_1852("");
                            updateSearchResults();
                        }
                        chestsort$clampLeftScroll();
                        return true;
                    }

                    TagFilterSpec tag = this.editingTags.get(idx);
                    String tagId = ContainerFilterSpec.normalizeTagId(tag == null ? "" : tag.tagId());
                    if (!tagId.isEmpty()) {
                        this.tagBrowserMode = true;
                        this.tagBrowserTagId = tagId;
                        rebuildTagBrowserItems();
                        if (this.searchField != null) {
                            this.searchField.method_1852("");
                        }
                        updateSearchResults();
                        return true;
                    }
                }
            }
        }

        // Right results: action adds
        int actionX1Right = (rightX + panelW) - ACTION_PAD - ACTION_W;
        int actionX2Right = (rightX + panelW) - ACTION_PAD;
        int resultsY = topY + 24 + 24 + HEADER_H;
        int rIdx = (int) ((mouseY - resultsY) / ROW_H);
        int realIdx = this.resultsScroll + rIdx;
        if (mouseX >= rightX && mouseX < rightX + panelW && mouseY >= resultsY) {
            if (mouseX >= actionX1Right && mouseX < actionX2Right) {
                if (realIdx >= 0 && realIdx < getResultsSize()) {
                    class_1792 entryItem = this.resultItems.get(realIdx);
                    String entryTagId = realIdx < this.resultTagIds.size() ? this.resultTagIds.get(realIdx) : "";

                    boolean isTag = entryItem == null && entryTagId != null && !entryTagId.isEmpty();
                    if (this.tagBrowserMode) {
                        if (isTag) {
                            String tagId = ContainerFilterSpec.normalizeTagId(entryTagId);
                            if (!tagId.isEmpty()) {
                                int existing = chestsort$indexOfTag(tagId);
                                if (existing >= 0) {
                                    chestsort$moveTagToTop(existing);
                                } else {
                                    this.editingTags.add(0, new TagFilterSpec(tagId, List.of()));
                                }

                                this.tagBrowserTagId = tagId;
                                rebuildTagBrowserItems();
                                if (this.searchField != null) this.searchField.method_1852("");
                                updateSearchResults();
                                return true;
                            }
                        }
                        if (entryItem != null) {
                            String itemId = String.valueOf(class_7923.field_41178.method_10221(entryItem));
                            addTagException(itemId);
                            return true;
                        }
                    } else if (isTag) {
                        String tagId = ContainerFilterSpec.normalizeTagId(entryTagId);
                        if (!tagId.isEmpty()) {
                            int existing = chestsort$indexOfTag(tagId);
                            if (existing >= 0) {
                                chestsort$moveTagToTop(existing);
                                return true;
                            }
                            this.editingTags.add(0, new TagFilterSpec(tagId, List.of()));
                            return true;
                        }
                    } else if (entryItem != null) {
                        String itemId = String.valueOf(class_7923.field_41178.method_10221(entryItem));
                        if (!itemId.isEmpty()) {
                            int existing = this.editingItems.indexOf(itemId);
                            if (existing >= 0) {
                                chestsort$moveItemToTop(existing);
                                return true;
                            }
                            this.editingItems.add(0, itemId);
                            return true;
                        }
                    }
                }
            }
        }

        return super.method_25402(click, bl);
    }

    private boolean hasTag(String tagIdRaw) {
        String tagId = ContainerFilterSpec.normalizeTagId(tagIdRaw);
        if (tagId.isEmpty()) return false;
        for (TagFilterSpec t : this.editingTags) {
            if (t != null && ContainerFilterSpec.normalizeTagId(t.tagId()).equals(tagId)) return true;
        }
        return false;
    }

    private int chestsort$indexOfTag(String tagIdRaw) {
        String tagId = ContainerFilterSpec.normalizeTagId(tagIdRaw);
        if (tagId.isEmpty()) return -1;
        for (int i = 0; i < this.editingTags.size(); i++) {
            TagFilterSpec t = this.editingTags.get(i);
            if (t != null && ContainerFilterSpec.normalizeTagId(t.tagId()).equals(tagId)) return i;
        }
        return -1;
    }

    private void chestsort$moveItemToTop(int idx) {
        if (idx <= 0 || idx >= this.editingItems.size()) return;
        String v = this.editingItems.remove(idx);
        this.editingItems.add(0, v);
    }

    private void chestsort$moveTagToTop(int idx) {
        if (idx <= 0 || idx >= this.editingTags.size()) return;
        TagFilterSpec v = this.editingTags.remove(idx);
        this.editingTags.add(0, v);
    }

    private void chestsort$bumpMatchingItemsToTop(String queryLower) {
        if (queryLower == null) return;
        String q = queryLower.trim().toLowerCase(java.util.Locale.ROOT);
        if (q.isEmpty() || q.startsWith("#")) return;

        ArrayList<String> matches = new ArrayList<>();
        ArrayList<String> rest = new ArrayList<>();
        for (String itemId : this.editingItems) {
            if (itemId == null) continue;
            String idLower = itemId.toLowerCase(java.util.Locale.ROOT);
            boolean match = idLower.contains(q);
            if (!match) {
                class_2960 id = class_2960.method_12829(itemId);
                if (id != null) {
                    class_1792 item = class_7923.field_41178.method_63535(id);
                    if (item != null) {
                        String name = class_2561.method_43471(item.method_7876()).getString().toLowerCase(java.util.Locale.ROOT);
                        match = name.contains(q);
                    }
                }
            }
            if (match) matches.add(itemId);
            else rest.add(itemId);
        }

        if (!matches.isEmpty()) {
            this.editingItems.clear();
            this.editingItems.addAll(matches);
            this.editingItems.addAll(rest);
        }
    }

    private void chestsort$bumpMatchingTagsToTop(String queryLower) {
        if (queryLower == null) return;
        String q = ContainerFilterSpec.normalizeTagId(queryLower).toLowerCase(java.util.Locale.ROOT);
        if (q.isEmpty() || !q.startsWith("#")) return;

        ArrayList<TagFilterSpec> matches = new ArrayList<>();
        ArrayList<TagFilterSpec> rest = new ArrayList<>();
        for (TagFilterSpec t : this.editingTags) {
            String tagId = ContainerFilterSpec.normalizeTagId(t == null ? "" : t.tagId());
            String tl = tagId.toLowerCase(java.util.Locale.ROOT);
            if (!tagId.isEmpty() && tl.contains(q)) matches.add(t);
            else rest.add(t);
        }

        if (!matches.isEmpty()) {
            this.editingTags.clear();
            this.editingTags.addAll(matches);
            this.editingTags.addAll(rest);
        }
    }

    private void chestsort$ensureItemTagIdsScanStarted() {
        if (this.chestsort$allItemTagIds != null) return;
        if (this.chestsort$tagIdScanStarted) return;
        this.chestsort$tagIdScanStarted = true;

        Thread t = new Thread(() -> {
            List<String> ids = chestsort$collectAllItemTagIds();
            this.chestsort$allItemTagIds = ids;
            class_310 mc = class_310.method_1551();
            if (mc != null) {
                mc.execute(this::updateSearchResults);
            }
        }, "chestsort-tag-ids");
        t.setDaemon(true);
        t.start();
    }

    private static List<String> chestsort$collectAllItemTagIds() {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        try {
            Object registry = class_7923.field_41178;
            List<String> methodNames = List.of("streamTags", "getTagNames", "getTags", "streamTagKeys", "getTagKeys");
            for (String methodName : methodNames) {
                java.lang.reflect.Method m;
                try {
                    m = registry.getClass().getMethod(methodName);
                } catch (NoSuchMethodException ignored) {
                    continue;
                }

                Object res = m.invoke(registry);
                if (res == null) continue;

                if (res instanceof java.util.stream.Stream<?> stream) {
                    stream.forEach(o -> chestsort$collectTagIdFromUnknown(o, out));
                } else if (res instanceof Iterable<?> it) {
                    for (Object o : it) chestsort$collectTagIdFromUnknown(o, out);
                }

                if (!out.isEmpty()) break;
            }
        } catch (Throwable ignored) {
        }

        ArrayList<String> list = new ArrayList<>(out.size());
        for (String s : out) {
            if (s == null) continue;
            String norm = ContainerFilterSpec.normalizeTagId(s);
            if (!norm.isEmpty()) list.add(norm);
        }
        list.sort(Comparator.naturalOrder());
        return List.copyOf(list);
    }

    private static void chestsort$collectTagIdFromUnknown(Object o, java.util.Set<String> out) {
        if (o == null) return;

        if (o instanceof class_6862<?> tagKey) {
            class_2960 id = tagKey.comp_327();
            if (id != null) out.add("#" + id);
            return;
        }

        if (o instanceof Map.Entry<?, ?> e) {
            Object k = e.getKey();
            if (k instanceof class_6862<?> tk) {
                class_2960 id = tk.comp_327();
                if (id != null) out.add("#" + id);
                return;
            }
        }

        try {
            for (String methodName : List.of("getKey", "getTag", "key", "tag")) {
                java.lang.reflect.Method m;
                try {
                    m = o.getClass().getMethod(methodName);
                } catch (NoSuchMethodException ignored) {
                    continue;
                }
                Object k = m.invoke(o);
                if (k instanceof class_6862<?> tk) {
                    class_2960 id = tk.comp_327();
                    if (id != null) out.add("#" + id);
                    return;
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private int getLeftRowKind(int rowIndex) {
        // 0 items header, 1 item row, 2 tags header, 3 tag row
        if (rowIndex == 0) return 0;
        int itemsN = this.editingItems.size();
        if (rowIndex >= 1 && rowIndex < 1 + itemsN) return 1;
        if (rowIndex == 1 + itemsN) return 2;
        int tagStart = 2 + itemsN;
        if (rowIndex >= tagStart && rowIndex < tagStart + this.editingTags.size()) return 3;
        return -1;
    }

    private int getLeftRowIndex(int rowIndex) {
        int itemsN = this.editingItems.size();
        if (rowIndex >= 1 && rowIndex < 1 + itemsN) return rowIndex - 1;
        int tagStart = 2 + itemsN;
        if (rowIndex >= tagStart && rowIndex < tagStart + this.editingTags.size()) return rowIndex - tagStart;
        return -1;
    }

    private int getResultsSize() {
        return this.resultItems == null ? 0 : this.resultItems.size();
    }

    private int getResultsRowsShown() {
        return Math.max(1, chestsort$getRowsAreaH() / ROW_H);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Avoid Screen.renderBackground(), which applies the GUI blur effect.
        // In newer Minecraft versions, blur can only be applied once per frame.
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xAA000000);

        class_327 tr = class_310.method_1551().field_1772;
        if (tr == null) {
            super.method_25394(context, mouseX, mouseY, delta);
            return;
        }

        int panelW = chestsort$panelW();
        int leftX = chestsort$leftX(panelW);
        int rightX = leftX + panelW + PANEL_GAP;
        int topY = Math.max(10, (this.field_22790 - PANEL_H) / 2);

        String headerText = this.presetName.isEmpty() ? "Preset editor" : ("Preset: " + this.presetName);
        context.method_27535(tr, class_2561.method_43470(headerText), leftX, topY - 10, 0xFFFFFFFF);

        // Panel backgrounds
        context.method_25294(leftX, topY, leftX + panelW, topY + PANEL_H, 0xAA000000);
        context.method_25294(rightX, topY, rightX + panelW, topY + PANEL_H, 0xAA000000);

        // Right header
        String rightTitle = this.tagBrowserMode ? ("Tag: " + this.tagBrowserTagId) : "Results";
        context.method_27535(tr, class_2561.method_43470(rightTitle), rightX + 6, topY + 6 + 24 + 24, 0xFFFFFFFF);

        // Tabs (left header row)
        int tabY1 = topY + 24 + 24;
        int tabY2 = tabY1 + HEADER_H;
        int half = panelW / 2;
        int wlColor = (this.chestsort$tab == TAB_WHITELIST) ? 0xFF303030 : 0xFF202020;
        int blColor = (this.chestsort$tab == TAB_BLACKLIST) ? 0xFF303030 : 0xFF202020;
        context.method_25294(leftX, tabY1, leftX + half, tabY2, wlColor);
        context.method_25294(leftX + half, tabY1, leftX + panelW, tabY2, blColor);
        context.method_27535(tr, class_2561.method_43470("Whitelist"), leftX + 8, tabY1 + 4, 0xFFFFFFFF);
        context.method_27535(tr, class_2561.method_43470("Blacklist"), leftX + half + 8, tabY1 + 4, 0xFFFFFFFF);

        int rowsY = topY + 24 + 24 + HEADER_H;
        int shownLeft = getLeftRowsShown();
        chestsort$clampLeftScroll();

        // Left rows
        int actionX1Left = (leftX + panelW) - ACTION_PAD - ACTION_W;
        int actionX2Left = (leftX + panelW) - ACTION_PAD;
        for (int visible = 0; visible < shownLeft; visible++) {
            int rowIndex = this.leftScroll + visible;
            int y = rowsY + (visible * ROW_H);
            int kind = getLeftRowKind(rowIndex);
            int idx = getLeftRowIndex(rowIndex);
            if (kind < 0) continue;

            context.method_25294(leftX + 6, y, leftX + panelW - 6, y + ROW_H - 1, 0xFF202020);

            if (kind == 0) {
                context.method_27535(tr, class_2561.method_43470("Items (" + this.editingItems.size() + ")"), leftX + 8, y + 5, 0xFFFFFFFF);
                continue;
            }
            if (kind == 2) {
                context.method_27535(tr, class_2561.method_43470("Tags (" + this.editingTags.size() + ")"), leftX + 8, y + 5, 0xFFFFFFFF);
                continue;
            }

            context.method_25294(actionX1Left, y, actionX2Left, y + ROW_H - 1, 0xFFFF5555);
            context.method_27535(tr, class_2561.method_43470("x"), actionX1Left + 4, y + 5, 0xFFFFFFFF);

            if (kind == 1) {
                if (idx < 0 || idx >= this.editingItems.size()) continue;
                String itemId = this.editingItems.get(idx);
                class_2960 id = class_2960.method_12829(itemId);
                if (id != null && class_7923.field_41178.method_10250(id)) {
                    class_1792 item = class_7923.field_41178.method_63535(id);
                    context.method_51427(new class_1799(item), leftX + 8, y + 1);
                    String name = class_2561.method_43471(item.method_7876()).getString();
                    context.method_27535(tr, class_2561.method_43470(tr.method_27523(name, actionX1Left - (leftX + 28) - 4)), leftX + 28, y + 2, 0xFFFFFFFF);
                    context.method_27535(tr, class_2561.method_43470(tr.method_27523(itemId, actionX1Left - (leftX + 28) - 4)), leftX + 28, y + 10, 0xFF9A9A9A);
                } else {
                    context.method_27535(tr, class_2561.method_43470(tr.method_27523(itemId, actionX1Left - (leftX + 8) - 4)), leftX + 8, y + 5, 0xFFFFFFFF);
                }
            } else if (kind == 3) {
                if (idx < 0 || idx >= this.editingTags.size()) continue;
                TagFilterSpec tag = this.editingTags.get(idx);
                String tagId = ContainerFilterSpec.normalizeTagId(tag == null ? "" : tag.tagId());
                class_1792 icon = chestsort$getTagCycleIcon(tagId);
                if (icon != null) {
                    context.method_51427(new class_1799(icon), leftX + 8, y + 1);
                }

                String name = chestsort$formatTagDisplayName(tagId);
                String sub = tagId;
                int textX = leftX + 28;
                int textW = Math.max(0, actionX1Left - textX - 4);
                context.method_27535(tr, class_2561.method_43470(textW <= 0 ? name : tr.method_27523(name, textW)), textX, y + 2, 0xFFFFFFFF);
                context.method_27535(tr, class_2561.method_43470(textW <= 0 ? sub : tr.method_27523(sub, textW)), textX, y + 10, 0xFF9A9A9A);
            }
        }

        // Right results rows
        int actionX1Right = (rightX + panelW) - ACTION_PAD - ACTION_W;
        int actionX2Right = (rightX + panelW) - ACTION_PAD;
        int shown = Math.min(getResultsRowsShown(), Math.max(0, getResultsSize() - this.resultsScroll));
        for (int i = 0; i < shown; i++) {
            int idx = this.resultsScroll + i;
            int y = rowsY + (i * ROW_H);
            context.method_25294(rightX + 6, y, rightX + panelW - 6, y + ROW_H - 1, 0xFF202020);

            class_1792 entryItem = this.resultItems.get(idx);
            String entryTagId = idx < this.resultTagIds.size() ? this.resultTagIds.get(idx) : "";
            String subtitle = idx < this.resultSubtitles.size() ? this.resultSubtitles.get(idx) : "";

            boolean isTag = entryItem == null && entryTagId != null && !entryTagId.isEmpty();
            boolean actionIsException = this.tagBrowserMode && !isTag;
            int actionColor = actionIsException ? 0xFFFF5555 : 0xFF55FF55;
            String actionText = actionIsException ? "x" : "+";
            context.method_25294(actionX1Right, y, actionX2Right, y + ROW_H - 1, actionColor);
            context.method_27535(tr, class_2561.method_43470(actionText), actionX1Right + 4, y + 5, 0xFFFFFFFF);

            if (isTag) {
                String tagId = ContainerFilterSpec.normalizeTagId(entryTagId);
                class_1792 icon = chestsort$getTagCycleIcon(tagId);
                if (icon != null) {
                    context.method_51427(new class_1799(icon), rightX + 8, y + 1);
                }

                String name = chestsort$formatTagDisplayName(tagId);
                String sub = subtitle == null || subtitle.isEmpty() ? tagId : subtitle;
                int textX = rightX + 28;
                int textW = Math.max(0, actionX1Right - textX - 4);
                context.method_27535(tr, class_2561.method_43470(textW <= 0 ? name : tr.method_27523(name, textW)), textX, y + 2, 0xFFFFFFFF);
                context.method_27535(tr, class_2561.method_43470(textW <= 0 ? sub : tr.method_27523(sub, textW)), textX, y + 10, 0xFF9A9A9A);
            } else if (entryItem != null) {
                context.method_51427(new class_1799(entryItem), rightX + 8, y + 1);
                String name = class_2561.method_43471(entryItem.method_7876()).getString();
                context.method_27535(tr, class_2561.method_43470(tr.method_27523(name, actionX1Right - (rightX + 28) - 4)), rightX + 28, y + 2, 0xFFFFFFFF);
                context.method_27535(tr, class_2561.method_43470(tr.method_27523(subtitle, actionX1Right - (rightX + 28) - 4)), rightX + 28, y + 10, 0xFF9A9A9A);
            }
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private static class_2960 parseTagIdentifier(String tagId) {
        if (tagId == null) return null;
        String t = tagId.trim();
        if (t.isEmpty()) return null;
        if (t.startsWith("#")) t = t.substring(1);
        return class_2960.method_12829(t);
    }

    private static String chestsort$formatTagDisplayName(String tagId) {
        if (tagId == null || tagId.isEmpty()) return "";
        String t = tagId.startsWith("#") ? tagId.substring(1) : tagId;
        int slash = t.indexOf(':');
        String path = slash >= 0 ? t.substring(slash + 1) : t;
        if (path.isEmpty()) return tagId;
        String[] parts = path.split("[_/\\\\-]+", -1);
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
        }
        return sb.length() == 0 ? tagId : sb.toString();
    }

    private class_1792 chestsort$getTagCycleIcon(String tagId) {
        class_2960 id = parseTagIdentifier(tagId);
        if (id == null) return null;
        List<class_1792> items = this.tagItemsCache.computeIfAbsent(tagId, k -> computeItemsForTag(id));
        if (items == null || items.isEmpty()) return null;
        long now = System.currentTimeMillis();
        int idx = (int) ((now / 750L) % items.size());
        return items.get(Math.max(0, Math.min(idx, items.size() - 1)));
    }

    private List<class_1792> computeItemsForTag(class_2960 tagIdentifier) {
        class_6862<class_1792> key = class_6862.method_40092(class_7924.field_41197, tagIdentifier);
        ArrayList<class_1792> out = new ArrayList<>();
        for (class_1792 item : class_7923.field_41178) {
            // Prefer default stack (avoids per-loop explicit new ItemStack(item)).
            if (item.method_7854().method_31573(key)) {
                out.add(item);
                if (out.size() >= 200) break;
            }
        }
        return List.copyOf(out);
    }

    private void rebuildTagBrowserItems() {
        class_2960 id = parseTagIdentifier(this.tagBrowserTagId);
        if (id == null) {
            this.tagBrowserItems = List.of();
            return;
        }
        List<class_1792> items = this.tagItemsCache.computeIfAbsent(this.tagBrowserTagId, k -> computeItemsForTag(id));
        this.tagBrowserItems = items == null ? List.of() : items;
    }

    private void addTagException(String itemId) {
        if (itemId == null || itemId.isEmpty()) return;
        String tagId = ContainerFilterSpec.normalizeTagId(this.tagBrowserTagId);
        if (tagId.isEmpty()) return;

        for (int i = 0; i < this.editingTags.size(); i++) {
            TagFilterSpec tag = this.editingTags.get(i);
            if (tag == null) continue;
            if (!ContainerFilterSpec.normalizeTagId(tag.tagId()).equals(tagId)) continue;

            LinkedHashSet<String> exc = new LinkedHashSet<>();
            if (tag.exceptions() != null) {
                for (String e : tag.exceptions()) {
                    if (e != null && !e.trim().isEmpty()) exc.add(e.trim());
                }
            }
            if (exc.add(itemId)) {
                this.editingTags.set(i, new TagFilterSpec(tagId, List.copyOf(exc)));
                updateSearchResults();
            }
            return;
        }
    }

    private java.util.Set<String> getExceptionSetForTag(String tagIdRaw) {
        String tagId = ContainerFilterSpec.normalizeTagId(tagIdRaw);
        if (tagId.isEmpty()) return java.util.Set.of();
        for (TagFilterSpec tag : this.editingTags) {
            if (tag == null) continue;
            if (!ContainerFilterSpec.normalizeTagId(tag.tagId()).equals(tagId)) continue;
            if (tag.exceptions() == null || tag.exceptions().isEmpty()) return java.util.Set.of();
            HashSet<String> out = new HashSet<>(tag.exceptions().size());
            for (String e : tag.exceptions()) {
                if (e == null) continue;
                String s = e.trim();
                if (!s.isEmpty()) out.add(s);
            }
            return out;
        }
        return java.util.Set.of();
    }
}
