package dev.dromer.chestsort.client;

import net.minecraft.class_12249;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9974;
import org.joml.Matrix4f;

public final class ClientFindHighlightRenderer {
    private ClientFindHighlightRenderer() {
    }

    private static final int OUTLINE_COLOR_ARGB = 0x80FFFF00;
    private static final float OUTLINE_LINE_WIDTH = 2.0f;

    public static void render(Matrix4f positionMatrix, class_4184 camera) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1687 == null || positionMatrix == null || camera == null) return;

        // Render wand selection overlay first (independent of /cs find highlights).
        ClientWandSelectionRenderer.render(positionMatrix, camera);

        String dimId = mc.field_1687.method_27983().method_29177().toString();
        if (!ClientFindHighlightState.isActiveFor(dimId)) return;

        class_4587 matrices = new class_4587();
        matrices.method_34425(positionMatrix);

        // WorldRenderer's matrices in 1.21.x are not guaranteed to include camera translation;
        // render in camera-relative coordinates to ensure the outline appears at the right place.
        class_243 camPos = camera.method_71156();

        class_4597.class_4598 consumers = mc.method_22940().method_23001();
        class_4588 lines = consumers.method_73477(class_12249.method_76015());

        for (Long l : ClientFindHighlightState.posLongs()) {
            if (l == null) continue;
            class_2338 pos = class_2338.method_10092(l);
            class_265 shape = mc.field_1687.method_8320(pos).method_26218(mc.field_1687, pos);
            if (shape == null || shape.method_1110()) continue;

            class_9974.method_62296(
                matrices,
                lines,
                shape,
                pos.method_10263() - camPos.field_1352,
                pos.method_10264() - camPos.field_1351,
                pos.method_10260() - camPos.field_1350,
                OUTLINE_COLOR_ARGB,
                OUTLINE_LINE_WIDTH
            );
        }

        consumers.method_22994(class_12249.method_76015());
    }
}
