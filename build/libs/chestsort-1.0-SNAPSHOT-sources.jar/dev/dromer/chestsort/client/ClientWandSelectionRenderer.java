package dev.dromer.chestsort.client;

import net.minecraft.class_12249;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9974;
import org.joml.Matrix4f;

public final class ClientWandSelectionRenderer {
    private ClientWandSelectionRenderer() {
    }

    private static final int REGION_COLOR_ARGB = 0x80FFFF00;
    private static final int POS1_COLOR_ARGB = 0x8000FF00;
    private static final int POS2_COLOR_ARGB = 0x80FF0000;
    private static final float REGION_LINE_WIDTH = 2.0f;
    private static final float POS_LINE_WIDTH = 3.0f;

    public static void render(Matrix4f positionMatrix, class_4184 camera) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1687 == null || positionMatrix == null || camera == null) return;

        String dimId = mc.field_1687.method_27983().method_29177().toString();

        boolean has1 = ClientWandSelectionState.hasPos1In(dimId);
        boolean has2 = ClientWandSelectionState.hasPos2In(dimId);
        if (!has1 && !has2) return;

        class_2338 p1 = ClientWandSelectionState.pos1();
        class_2338 p2 = ClientWandSelectionState.pos2();

        class_4587 matrices = new class_4587();
        matrices.method_34425(positionMatrix);

        class_243 camPos = camera.method_71156();

        class_4597.class_4598 consumers = mc.method_22940().method_23001();
        class_4588 lines = consumers.method_73477(class_12249.method_76015());

        if (has1 && p1 != null) {
            class_265 shape = mc.field_1687.method_8320(p1).method_26218(mc.field_1687, p1);
            if (shape != null && !shape.method_1110()) {
                class_9974.method_62296(matrices, lines, shape,
                    p1.method_10263() - camPos.field_1352,
                    p1.method_10264() - camPos.field_1351,
                    p1.method_10260() - camPos.field_1350,
                    POS1_COLOR_ARGB,
                    POS_LINE_WIDTH);
            }
        }

        if (has2 && p2 != null) {
            class_265 shape = mc.field_1687.method_8320(p2).method_26218(mc.field_1687, p2);
            if (shape != null && !shape.method_1110()) {
                class_9974.method_62296(matrices, lines, shape,
                    p2.method_10263() - camPos.field_1352,
                    p2.method_10264() - camPos.field_1351,
                    p2.method_10260() - camPos.field_1350,
                    POS2_COLOR_ARGB,
                    POS_LINE_WIDTH);
            }
        }

        if (has1 && has2 && p1 != null && p2 != null) {
            int minX = Math.min(p1.method_10263(), p2.method_10263());
            int minY = Math.min(p1.method_10264(), p2.method_10264());
            int minZ = Math.min(p1.method_10260(), p2.method_10260());
            int maxX = Math.max(p1.method_10263(), p2.method_10263());
            int maxY = Math.max(p1.method_10264(), p2.method_10264());
            int maxZ = Math.max(p1.method_10260(), p2.method_10260());

            double sx = (double) (maxX - minX + 1);
            double sy = (double) (maxY - minY + 1);
            double sz = (double) (maxZ - minZ + 1);

            class_265 box = class_259.method_1078(new class_238(0, 0, 0, sx, sy, sz));

            class_9974.method_62296(
                matrices,
                lines,
                box,
                minX - camPos.field_1352,
                minY - camPos.field_1351,
                minZ - camPos.field_1350,
                REGION_COLOR_ARGB,
                REGION_LINE_WIDTH
            );
        }

        consumers.method_22994(class_12249.method_76015());
    }
}
