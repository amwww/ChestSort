package dev.dromer.chestsort.command;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;

import dev.dromer.chestsort.data.ChestSortState;
import dev.dromer.chestsort.data.ContainerSnapshot;
import dev.dromer.chestsort.filter.ContainerFilterSpec;
import dev.dromer.chestsort.filter.TagFilterSpec;
import dev.dromer.chestsort.net.payload.FindHighlightsPayload;
import dev.dromer.chestsort.net.payload.OpenPresetUiPayload;
import dev.dromer.chestsort.net.payload.WandSelectionPayload;
import dev.dromer.chestsort.util.ContainerCanonicalizer;
import dev.dromer.chestsort.util.WandSelectionUtil;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2262;
import net.minecraft.class_2287;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_6862;
import net.minecraft.class_7157;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;

public final class ChestSortCommands {
    private ChestSortCommands() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> register(dispatcher, registryAccess));
    }

    private static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess) {
        dispatcher.register(class_2170.method_9247("cs")
            .then(class_2170.method_9247("help")
                .executes(ctx -> help(ctx.getSource())))
            .then(class_2170.method_9247("autosort")
                .then(class_2170.method_9244("mode", StringArgumentType.word())
                    .suggests((ctx, builder) -> {
                        builder.suggest(ChestSortState.AUTOSORT_NEVER);
                        builder.suggest(ChestSortState.AUTOSORT_SELECTED);
                        builder.suggest(ChestSortState.AUTOSORT_ALWAYS);
                        return builder.buildFuture();
                    })
                    .executes(ctx -> autosortMode(ctx.getSource(), StringArgumentType.getString(ctx, "mode")))))
            .then(class_2170.method_9247("highlights")
                .then(class_2170.method_9247("dismiss")
                    .executes(ctx -> highlightsDismiss(ctx.getSource())))
                .then(class_2170.method_9244("mode", StringArgumentType.word())
                    .suggests((ctx, builder) -> {
                        builder.suggest(ChestSortState.HIGHLIGHTS_ON);
                        builder.suggest(ChestSortState.HIGHLIGHTS_OFF);
                        builder.suggest(ChestSortState.HIGHLIGHTS_UNTIL_OPENED);
                        return builder.buildFuture();
                    })
                    .executes(ctx -> highlightsMode(ctx.getSource(), StringArgumentType.getString(ctx, "mode")))))
            .then(class_2170.method_9247("tags")
                .then(class_2170.method_9244("item", class_2287.method_9776(registryAccess))
                    .executes(ctx -> tags(ctx.getSource(), class_2287.method_9777(ctx, "item").method_9785()))))
            .then(class_2170.method_9247("blacklist")
                .then(class_2170.method_9247("list")
                    .executes(ctx -> blacklistList(ctx.getSource())))
                .then(class_2170.method_9247("clear")
                    .executes(ctx -> blacklistClear(ctx.getSource())))
                .then(class_2170.method_9247("mode")
                    .executes(ctx -> blacklistMode(ctx.getSource(), ""))
                    .then(class_2170.method_9244("mode", StringArgumentType.word())
                        .suggests((ctx, builder) -> {
                            builder.suggest("preventSort");
                            builder.suggest("strictPreventSort");
                            builder.suggest("preventEntry");
                            builder.suggest("strictPreventEntry");
                            return builder.buildFuture();
                        })
                        .executes(ctx -> blacklistMode(ctx.getSource(), StringArgumentType.getString(ctx, "mode")))))
                .then(class_2170.method_9247("add")
                    .then(class_2170.method_9244("item", class_2287.method_9776(registryAccess))
                        .executes(ctx -> blacklistAdd(ctx.getSource(), class_2287.method_9777(ctx, "item").method_9785()))))
                .then(class_2170.method_9247("addPreset")
                    .then(class_2170.method_9244("name", StringArgumentType.string())
                        .suggests((ctx, builder) -> suggestPresetName(ctx.getSource(), builder))
                        .then(class_2170.method_9244("mode", StringArgumentType.word())
                            .suggests((ctx, builder) -> {
                                builder.suggest("blacklist");
                                builder.suggest("whitelist");
                                builder.suggest("everything");
                                return builder.buildFuture();
                            })
                            .executes(ctx -> blacklistAddPreset(
                                ctx.getSource(),
                                StringArgumentType.getString(ctx, "name"),
                                StringArgumentType.getString(ctx, "mode")
                            )))))
                .then(class_2170.method_9247("remove")
                    .then(class_2170.method_9244("item", class_2287.method_9776(registryAccess))
                        .executes(ctx -> blacklistRemove(ctx.getSource(), class_2287.method_9777(ctx, "item").method_9785()))))
            )
            .then(class_2170.method_9247("scan")
                .executes(ctx -> scan(ctx.getSource())))
            .then(class_2170.method_9247("find")
                .then(class_2170.method_9244("item", class_2287.method_9776(registryAccess))
                    .executes(ctx -> find(ctx.getSource(), class_2287.method_9777(ctx, "item").method_9785()))))
            .then(class_2170.method_9247("presets")
                .then(class_2170.method_9247("list")
                    .executes(ctx -> presetsList(ctx.getSource())))
                .then(class_2170.method_9247("add")
                    .then(class_2170.method_9244("name", StringArgumentType.string())
                        .executes(ctx -> presetsAdd(ctx.getSource(), StringArgumentType.getString(ctx, "name")))))
                .then(class_2170.method_9247("duplicate")
                    .then(class_2170.method_9244("name", StringArgumentType.string())
                        .suggests((ctx, builder) -> suggestPresetName(ctx.getSource(), builder))
                        .executes(ctx -> presetsDuplicate(ctx.getSource(), StringArgumentType.getString(ctx, "name")))))
                .then(class_2170.method_9247("remove")
                    .then(class_2170.method_9244("name", StringArgumentType.string())
                        .suggests((ctx, builder) -> suggestPresetName(ctx.getSource(), builder))
                        .executes(ctx -> presetsRemove(ctx.getSource(), StringArgumentType.getString(ctx, "name")))))
                .then(class_2170.method_9247("rename")
                    .then(class_2170.method_9244("old", StringArgumentType.string())
                        .suggests((ctx, builder) -> suggestPresetName(ctx.getSource(), builder))
                        .then(class_2170.method_9244("new", StringArgumentType.string())
                            .executes(ctx -> presetsRename(ctx.getSource(), StringArgumentType.getString(ctx, "old"), StringArgumentType.getString(ctx, "new"))))))
                .then(class_2170.method_9247("edit")
                    .then(class_2170.method_9244("name", StringArgumentType.string())
                        .suggests((ctx, builder) -> suggestPresetName(ctx.getSource(), builder))
                        .executes(ctx -> presetsEdit(ctx.getSource(), StringArgumentType.getString(ctx, "name")))))
                .then(class_2170.method_9247("import")
                    .executes(ctx -> presetsOpenUi(ctx.getSource(), OpenPresetUiPayload.MODE_IMPORT, "")))
                .then(class_2170.method_9247("export")
                    .then(class_2170.method_9244("name", StringArgumentType.string())
                        .suggests((ctx, builder) -> suggestPresetName(ctx.getSource(), builder))
                        .executes(ctx -> presetsOpenUi(ctx.getSource(), OpenPresetUiPayload.MODE_EXPORT, StringArgumentType.getString(ctx, "name")))))
                .then(class_2170.method_9247("exportSelect")
                    .executes(ctx -> presetsOpenUi(ctx.getSource(), OpenPresetUiPayload.MODE_EXPORT_SELECT, "")))
                .then(class_2170.method_9247("exportAll")
                    .executes(ctx -> presetsOpenUi(ctx.getSource(), OpenPresetUiPayload.MODE_EXPORT_ALL, "")))
            )
            .then(class_2170.method_9247("wand")
                .then(class_2170.method_9247("bind")
                    .executes(ctx -> wandBind(ctx.getSource())))
                .then(class_2170.method_9247("unbind")
                    .executes(ctx -> wandUnbind(ctx.getSource())))
                .then(class_2170.method_9247("deselect")
                    .executes(ctx -> wandDeselect(ctx.getSource())))
                .then(class_2170.method_9247("copy")
                    .then(class_2170.method_9244("pos", class_2262.method_9698())
                        .suggests((ctx, builder) -> suggestLookBlock(ctx.getSource(), builder))
                        .executes(ctx -> wandCopy(ctx.getSource(), class_2262.method_48299(ctx, "pos"))))
                    .executes(ctx -> wandCopy(ctx.getSource(), null)))
                .then(class_2170.method_9247("paste")
                    .executes(ctx -> wandPaste(ctx.getSource())))
                .then(class_2170.method_9247("autosort")
                    .then(class_2170.method_9244("mode", StringArgumentType.word())
                        .suggests((ctx, builder) -> {
                            builder.suggest("on");
                            builder.suggest("off");
                            return builder.buildFuture();
                        })
                        .executes(ctx -> wandAutosort(ctx.getSource(), StringArgumentType.getString(ctx, "mode")))))
                .then(class_2170.method_9247("clear")
                    .executes(ctx -> wandClear(ctx.getSource())))
                .then(class_2170.method_9247("merge")
                    .executes(ctx -> wandMerge(ctx.getSource())))
            )
        );
    }

    private static CompletableFuture<Suggestions> suggestLookBlock(class_2168 source, SuggestionsBuilder builder) {
        class_3222 player = source.method_44023();
        if (player == null) return builder.buildFuture();

        class_239 hit = player.method_5745(6.0, 0.0f, false);
        if (hit instanceof class_3965 bhr && hit.method_17783() == class_239.class_240.field_1332) {
            var pos = bhr.method_17777();
            builder.suggest(pos.method_10263() + " " + pos.method_10264() + " " + pos.method_10260());
        }
        return builder.buildFuture();
    }

    private static CompletableFuture<Suggestions> suggestPresetName(class_2168 source, SuggestionsBuilder builder) {
        if (source == null) return builder.buildFuture();
        ChestSortState state = ChestSortState.get(source.method_9211());
        return class_2172.method_9265(state.getPresets().keySet(), builder);
    }

    private static class_3218 getWorldByDimId(MinecraftServer server, String dimId) {
        if (server == null || dimId == null || dimId.isEmpty()) return null;
        for (class_3218 w : server.method_3738()) {
            if (w == null) continue;
            String id = w.method_27983().method_29177().toString();
            if (dimId.equals(id)) return w;
        }
        return null;
    }

    private static int wandBind(class_2168 source) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs wand bind must be run by a player"));
            return 0;
        }

        class_1799 held = player.method_6047();
        if (held == null || held.method_7960()) {
            source.method_9213(class_2561.method_43470("[CS] Hold an item in your main hand to bind as the wand"));
            return 0;
        }

        String itemId = String.valueOf(class_7923.field_41178.method_10221(held.method_7909()));
        ChestSortState state = ChestSortState.get(source.method_9211());
        state.setWandItemId(player.method_5845(), itemId);

        // Sync to client so click interception works immediately.
        String uuid = player.method_5845();
        var p1 = state.getWandPos1(uuid);
        var p2 = state.getWandPos2(uuid);
        ServerPlayNetworking.send(player, new WandSelectionPayload(
            itemId,
            p1 != null,
            p1 == null ? "" : p1.dimensionId(),
            p1 == null ? 0L : p1.posLong(),
            p2 != null,
            p2 == null ? "" : p2.dimensionId(),
            p2 == null ? 0L : p2.posLong(),
            0L,
            0
        ));

        source.method_9226(() -> class_2561.method_43470("[CS] Wand bound to: ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470(itemId).method_27692(class_124.field_1054)), false);
        return 1;
    }

    private static int wandUnbind(class_2168 source) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs wand unbind must be run by a player"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(source.method_9211());
        String uuid = player.method_5845();

        state.setWandItemId(uuid, "");
        state.clearWandSelection(uuid);
        state.clearWandClipboard(uuid);

        ServerPlayNetworking.send(player, new WandSelectionPayload(
            "",
            false,
            "",
            0L,
            false,
            "",
            0L,
            0L,
            0
        ));

        source.method_9226(() -> class_2561.method_43470("[CS] Wand unbound").method_27692(class_124.field_1065), false);
        return 1;
    }

    private static int wandDeselect(class_2168 source) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs wand deselect must be run by a player"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(source.method_9211());
        String uuid = player.method_5845();
        String wandItemId = state.getWandItemId(uuid);
        if (wandItemId == null || wandItemId.isEmpty()) {
            source.method_9213(class_2561.method_43470("[CS] No wand is bound. Use /cs wand bind first."));
            return 0;
        }

        state.clearWandSelection(uuid);

        ServerPlayNetworking.send(player, new WandSelectionPayload(
            wandItemId,
            false,
            "",
            0L,
            false,
            "",
            0L,
            0L,
            0
        ));

        source.method_9226(() -> class_2561.method_43470("[CS] Wand selection cleared").method_27692(class_124.field_1065), false);
        return 1;
    }

    private static int wandCopy(class_2168 source, net.minecraft.class_2338 posArg) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs wand copy must be run by a player"));
            return 0;
        }

        if (!(player.method_51469() instanceof class_3218 world)) {
            source.method_9213(class_2561.method_43470("[CS] Not in a server world"));
            return 0;
        }
        net.minecraft.class_2338 pos = posArg;
        if (pos == null) {
            class_239 hit = player.method_5745(6.0, 0.0f, false);
            if (hit instanceof class_3965 bhr && hit.method_17783() == class_239.class_240.field_1332) {
                pos = bhr.method_17777();
            }
        }
        if (pos == null) {
            source.method_9213(class_2561.method_43470("[CS] Look at a container block (or pass a block position)"));
            return 0;
        }

        var be = world.method_8321(pos);
        if (be == null) {
            source.method_9213(class_2561.method_43470("[CS] No block entity at that position"));
            return 0;
        }

        var canonical = ContainerCanonicalizer.canonicalize(world, pos, be);
        if (canonical.snapshotInventory() == null) {
            source.method_9213(class_2561.method_43470("[CS] That block is not a supported container"));
            return 0;
        }

        String dimId = world.method_27983().method_29177().toString();
        long canonicalPosLong = canonical.posLong();

        ChestSortState state = ChestSortState.get(source.method_9211());
        ContainerFilterSpec spec = state.getFilterSpec(dimId, canonicalPosLong);
        state.setWandClipboard(player.method_5845(), spec);

        source.method_9226(() -> class_2561.method_43470("[CS] Copied filter to wand clipboard").method_27692(class_124.field_1065), false);
        return 1;
    }

    private static ChestSortState.WandPos requireWandPos(ChestSortState state, String uuid, int which, class_2168 source) {
        ChestSortState.WandPos pos = (which == 1) ? state.getWandPos1(uuid) : state.getWandPos2(uuid);
        if (pos == null) {
            source.method_9213(class_2561.method_43470("[CS] Missing wand pos" + which + ". Set pos1 with left-click and pos2 with right-click using your bound wand."));
        }
        return pos;
    }

    private static int wandPaste(class_2168 source) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs wand paste must be run by a player"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(source.method_9211());
        String uuid = player.method_5845();
        ContainerFilterSpec clip = state.getWandClipboard(uuid);
        if (clip == null) {
            source.method_9213(class_2561.method_43470("[CS] Wand clipboard is empty. Use /cs wand copy first."));
            return 0;
        }

        ChestSortState.WandPos p1 = requireWandPos(state, uuid, 1, source);
        ChestSortState.WandPos p2 = requireWandPos(state, uuid, 2, source);
        if (p1 == null || p2 == null) return 0;
        if (!p1.dimensionId().equals(p2.dimensionId())) {
            source.method_9213(class_2561.method_43470("[CS] pos1 and pos2 must be in the same dimension"));
            return 0;
        }

        class_3218 world = getWorldByDimId(source.method_9211(), p1.dimensionId());
        if (world == null) {
            source.method_9213(class_2561.method_43470("[CS] Could not resolve world for dimension: " + p1.dimensionId()));
            return 0;
        }

        Set<Long> targets = WandSelectionUtil.findLoadedContainerCanonicalPosLongsInBox(world, p1.pos(), p2.pos());
        for (long posLong : targets) {
            state.setFilterSpec(p1.dimensionId(), posLong, clip);
        }

        source.method_9226(() -> class_2561.method_43470("[CS] Pasted filter to ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470(String.valueOf(targets.size())).method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" containers (loaded)").method_27692(class_124.field_1080)), false);
        return 1;
    }

    private static int wandAutosort(class_2168 source, String mode) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs wand autosort must be run by a player"));
            return 0;
        }

        boolean on;
        String m = mode == null ? "" : mode.trim().toLowerCase();
        if ("on".equals(m)) on = true;
        else if ("off".equals(m)) on = false;
        else {
            source.method_9213(class_2561.method_43470("[CS] Invalid mode. Use: on | off"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(source.method_9211());
        String uuid = player.method_5845();
        ChestSortState.WandPos p1 = requireWandPos(state, uuid, 1, source);
        ChestSortState.WandPos p2 = requireWandPos(state, uuid, 2, source);
        if (p1 == null || p2 == null) return 0;
        if (!p1.dimensionId().equals(p2.dimensionId())) {
            source.method_9213(class_2561.method_43470("[CS] pos1 and pos2 must be in the same dimension"));
            return 0;
        }

        class_3218 world = getWorldByDimId(source.method_9211(), p1.dimensionId());
        if (world == null) {
            source.method_9213(class_2561.method_43470("[CS] Could not resolve world for dimension: " + p1.dimensionId()));
            return 0;
        }

        Set<Long> targets = WandSelectionUtil.findLoadedContainerCanonicalPosLongsInBox(world, p1.pos(), p2.pos());
        for (long posLong : targets) {
            ContainerFilterSpec existing = state.getFilterSpec(p1.dimensionId(), posLong);
            ContainerFilterSpec updated = new ContainerFilterSpec(existing.items(), existing.tags(), existing.presets(), on).normalized();
            state.setFilterSpec(p1.dimensionId(), posLong, updated);
        }

        source.method_9226(() -> class_2561.method_43470("[CS] Set autosort ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470(on ? "ON" : "OFF").method_27692(on ? class_124.field_1060 : class_124.field_1061))
            .method_10852(class_2561.method_43470(" for ").method_27692(class_124.field_1080))
            .method_10852(class_2561.method_43470(String.valueOf(targets.size())).method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" containers (loaded)").method_27692(class_124.field_1080)), false);
        return 1;
    }

    private static int wandClear(class_2168 source) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs wand clear must be run by a player"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(source.method_9211());
        String uuid = player.method_5845();
        ChestSortState.WandPos p1 = requireWandPos(state, uuid, 1, source);
        ChestSortState.WandPos p2 = requireWandPos(state, uuid, 2, source);
        if (p1 == null || p2 == null) return 0;
        if (!p1.dimensionId().equals(p2.dimensionId())) {
            source.method_9213(class_2561.method_43470("[CS] pos1 and pos2 must be in the same dimension"));
            return 0;
        }

        class_3218 world = getWorldByDimId(source.method_9211(), p1.dimensionId());
        if (world == null) {
            source.method_9213(class_2561.method_43470("[CS] Could not resolve world for dimension: " + p1.dimensionId()));
            return 0;
        }

        ContainerFilterSpec cleared = new ContainerFilterSpec(List.of(), List.of(), List.of(), false);
        Set<Long> targets = WandSelectionUtil.findLoadedContainerCanonicalPosLongsInBox(world, p1.pos(), p2.pos());
        for (long posLong : targets) {
            state.setFilterSpec(p1.dimensionId(), posLong, cleared);
        }

        source.method_9226(() -> class_2561.method_43470("[CS] Cleared filters for ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470(String.valueOf(targets.size())).method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" containers (loaded)").method_27692(class_124.field_1080)), false);
        return 1;
    }

    private static int wandMerge(class_2168 source) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs wand merge must be run by a player"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(source.method_9211());
        String uuid = player.method_5845();
        ChestSortState.WandPos p1 = requireWandPos(state, uuid, 1, source);
        ChestSortState.WandPos p2 = requireWandPos(state, uuid, 2, source);
        if (p1 == null || p2 == null) return 0;
        if (!p1.dimensionId().equals(p2.dimensionId())) {
            source.method_9213(class_2561.method_43470("[CS] pos1 and pos2 must be in the same dimension"));
            return 0;
        }

        class_3218 world = getWorldByDimId(source.method_9211(), p1.dimensionId());
        if (world == null) {
            source.method_9213(class_2561.method_43470("[CS] Could not resolve world for dimension: " + p1.dimensionId()));
            return 0;
        }

        Set<Long> targets = WandSelectionUtil.findLoadedContainerCanonicalPosLongsInBox(world, p1.pos(), p2.pos());

        LinkedHashSet<String> mergedItems = new LinkedHashSet<>();
        LinkedHashSet<String> mergedPresets = new LinkedHashSet<>();
        LinkedHashMap<String, LinkedHashSet<String>> mergedTags = new LinkedHashMap<>();
        boolean anyAutosort = false;

        for (long posLong : targets) {
            ContainerFilterSpec spec = state.getFilterSpec(p1.dimensionId(), posLong);
            if (spec == null) continue;
            ContainerFilterSpec s = spec.normalized();
            anyAutosort |= s.autosort();
            if (s.items() != null) mergedItems.addAll(s.items());
            if (s.presets() != null) mergedPresets.addAll(s.presets());
            if (s.tags() != null) {
                for (var t : s.tags()) {
                    if (t == null || t.tagId() == null) continue;
                    String tagId = ContainerFilterSpec.normalizeTagId(t.tagId());
                    if (tagId.isEmpty()) continue;
                    LinkedHashSet<String> exc = mergedTags.computeIfAbsent(tagId, k -> new LinkedHashSet<>());
                    if (t.exceptions() != null) exc.addAll(ContainerFilterSpec.normalizeStrings(t.exceptions()));
                }
            }
        }

        ArrayList<dev.dromer.chestsort.filter.TagFilterSpec> tags = new ArrayList<>(mergedTags.size());
        for (var e : mergedTags.entrySet()) {
            tags.add(new dev.dromer.chestsort.filter.TagFilterSpec(e.getKey(), List.copyOf(e.getValue())));
        }

        ContainerFilterSpec merged = new ContainerFilterSpec(List.copyOf(mergedItems), tags, List.copyOf(mergedPresets), anyAutosort).normalized();
        state.setWandClipboard(uuid, merged);

        source.method_9226(() -> class_2561.method_43470("[CS] Merged ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470(String.valueOf(targets.size())).method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" containers into wand clipboard").method_27692(class_124.field_1080)), false);
        return 1;
    }

    private static int help(class_2168 source) {
        source.method_9226(() -> class_2561.method_43470("[CS] ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470("ChestSort help").method_27692(class_124.field_1054)), false);
        source.method_9226(() -> class_2561.method_43470(""), false);

        source.method_9226(() -> class_2561.method_43470("What this mod does:").method_27692(class_124.field_1075), false);
        source.method_9226(() -> class_2561.method_43470("- Lets you define per-container filter rules (items + tags).").method_27692(class_124.field_1080), false);
        source.method_9226(() -> class_2561.method_43470("- Lets you save reusable rules as presets, then apply them to containers.").method_27692(class_124.field_1080), false);
        source.method_9226(() -> class_2561.method_43470("- Adds a container-side UI to edit rules and a preset editor UI.").method_27692(class_124.field_1080), false);
        source.method_9226(() -> class_2561.method_43470(""), false);

        source.method_9226(() -> class_2561.method_43470("Container filter UI (how to use):").method_27692(class_124.field_1075), false);
        source.method_9226(() -> class_2561.method_43470("- Open a chest/barrel, then click the \"Filter\" button.").method_27692(class_124.field_1080), false);
        source.method_9226(() -> class_2561.method_43470("- Left panel shows your current filter (Filter Items / Filter Tags / Filter Presets).").method_27692(class_124.field_1080), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("Autosort").method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" toggle (left panel) enables automatic sorting for that container (depending on ").method_27692(class_124.field_1080))
            .method_10852(class_2561.method_43470("/cs autosort").method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470(" mode).").method_27692(class_124.field_1080)), false);
        source.method_9226(() -> class_2561.method_43470("- Right panel shows search results; click the green + to add.").method_27692(class_124.field_1080), false);
        source.method_9226(() -> class_2561.method_43470("- Click a tag on the left to open its exception browser; green + adds exceptions, red x removes.").method_27692(class_124.field_1080), false);
        source.method_9226(() -> class_2561.method_43470(""), false);

        source.method_9226(() -> class_2561.method_43470("Search tips:").method_27692(class_124.field_1075), false);
        source.method_9226(() -> class_2561.method_43470("- Type normal text to search items.").method_27692(class_124.field_1080), false);
        source.method_9226(() -> class_2561.method_43470("- Type ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("#something").method_27692(class_124.field_1076))
            .method_10852(class_2561.method_43470(" to search tags.").method_27692(class_124.field_1080)), false);
        source.method_9226(() -> class_2561.method_43470("- Type ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("&name").method_27692(class_124.field_1076))
            .method_10852(class_2561.method_43470(" to search presets and add them to the container.").method_27692(class_124.field_1080)), false);
        source.method_9226(() -> class_2561.method_43470(""), false);

        source.method_9226(() -> class_2561.method_43470("Presets (local vs global editing):").method_27692(class_124.field_1075), false);
        source.method_9226(() -> class_2561.method_43470("- Add presets to a container via ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("&search").method_27692(class_124.field_1076))
            .method_10852(class_2561.method_43470("; applied presets then appear on the left list.").method_27692(class_124.field_1080)), false);
        source.method_9226(() -> class_2561.method_43470("- Click a preset on the left to edit it locally for this container.").method_27692(class_124.field_1080), false);
        source.method_9226(() -> class_2561.method_43470("- If local edits are unsaved, the preset name shows an ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("*").method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(".").method_27692(class_124.field_1080)), false);
        source.method_9226(() -> class_2561.method_43470("- Toggle \"Edit preset\" to edit the global preset (affects all containers).").method_27692(class_124.field_1080), false);
        source.method_9226(() -> class_2561.method_43470(""), false);

        source.method_9226(() -> class_2561.method_43470("Import / export presets:").method_27692(class_124.field_1075), false);
        source.method_9226(() -> class_2561.method_43470("- Export creates a ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("cs2|").method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" string you can share.").method_27692(class_124.field_1080)), false);
        source.method_9226(() -> class_2561.method_43470("- Import takes a ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("cs2|").method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" string and creates a new preset.").method_27692(class_124.field_1080)), false);
        source.method_9226(() -> class_2561.method_43470(""), false);

        source.method_9226(() -> class_2561.method_43470("Commands:").method_27692(class_124.field_1075), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("/cs scan").method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470("  (rescans loaded containers for ").method_27692(class_124.field_1080))
            .method_10852(class_2561.method_43470("/cs find").method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470(")").method_27692(class_124.field_1080)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("/cs find <item>").method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470("  (lists containers that contain an item)").method_27692(class_124.field_1080)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080).method_10852(class_2561.method_43470("/cs presets add <name>").method_27692(class_124.field_1060)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080).method_10852(class_2561.method_43470("/cs presets duplicate <name>").method_27692(class_124.field_1060)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080).method_10852(class_2561.method_43470("/cs presets remove <name>").method_27692(class_124.field_1060)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080).method_10852(class_2561.method_43470("/cs presets rename <old> <new>").method_27692(class_124.field_1060)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080).method_10852(class_2561.method_43470("/cs presets edit <name>").method_27692(class_124.field_1060)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080).method_10852(class_2561.method_43470("/cs presets list").method_27692(class_124.field_1060)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080).method_10852(class_2561.method_43470("/cs presets import").method_27692(class_124.field_1060)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080).method_10852(class_2561.method_43470("/cs presets export <name>").method_27692(class_124.field_1060)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080).method_10852(class_2561.method_43470("/cs presets exportSelect").method_27692(class_124.field_1060)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080).method_10852(class_2561.method_43470("/cs presets exportAll").method_27692(class_124.field_1060)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("/cs autosort ").method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470("<never|selected|always>").method_27692(class_124.field_1054)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("/cs highlights ").method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470("<on|off|until_opened>").method_27692(class_124.field_1054)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("/cs highlights dismiss").method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470("  (clears current highlights)").method_27692(class_124.field_1080)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("/cs blacklist ").method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470("<list|add|remove|clear>").method_27692(class_124.field_1054)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("/cs blacklist addPreset ").method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470("<name> ").method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470("<blacklist|whitelist|everything>").method_27692(class_124.field_1054)), false);
        source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("/cs blacklist mode ").method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470("<preventSort|strictPreventSort|preventEntry|strictPreventEntry>").method_27692(class_124.field_1054)), false);
        return 1;
    }

    private static int autosortMode(class_2168 source, String mode) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs autosort must be run by a player"));
            return 0;
        }

        String m = mode == null ? "" : mode.trim().toLowerCase();
        if (!ChestSortState.AUTOSORT_NEVER.equals(m) && !ChestSortState.AUTOSORT_SELECTED.equals(m) && !ChestSortState.AUTOSORT_ALWAYS.equals(m)) {
            source.method_9213(class_2561.method_43470("[CS] Invalid autosort mode. Use: never | selected | always"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(source.method_9211());
        state.setAutosortMode(player.method_5845(), m);
        source.method_9226(() -> class_2561.method_43470("[CS] Autosort mode set to: " + m), false);
        return 1;
    }

    private static int highlightsMode(class_2168 source, String mode) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs highlights must be run by a player"));
            return 0;
        }

        String m = mode == null ? "" : mode.trim().toLowerCase();
        if (!ChestSortState.HIGHLIGHTS_ON.equals(m) && !ChestSortState.HIGHLIGHTS_OFF.equals(m) && !ChestSortState.HIGHLIGHTS_UNTIL_OPENED.equals(m)) {
            source.method_9213(class_2561.method_43470("[CS] Invalid highlights mode. Use: on | off | until_opened"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(source.method_9211());
        String uuid = player.method_5845();
        state.setHighlightsMode(uuid, m);

        String currentDim = player.method_51469().method_27983().method_29177().toString();
        String lastItem = state.getLastFindItem(uuid);
        if (lastItem == null) lastItem = "";

        boolean highlightsOff = ChestSortState.HIGHLIGHTS_OFF.equals(m);
        boolean untilOpened = ChestSortState.HIGHLIGHTS_UNTIL_OPENED.equals(m);

        if (highlightsOff) {
            // Clear any existing in-world/container highlights immediately.
            ServerPlayNetworking.send(player, new FindHighlightsPayload(currentDim, lastItem, List.of()));
            ServerPlayNetworking.send(player, new dev.dromer.chestsort.net.payload.ContainerHighlightPayload("", false));
            state.clearHighlightsOnNextOpen(uuid);
        } else {
            // Restore last-find highlights (if any) immediately.
            if (!lastItem.isEmpty()) {
                List<ContainerSnapshot.Match> matches = state.find(lastItem);
                java.util.ArrayList<Long> highlightPos = new java.util.ArrayList<>();
                for (ContainerSnapshot.Match match : matches) {
                    if (match == null) continue;
                    if (!currentDim.equals(match.dimensionId())) continue;
                    if (match.pos() == null) continue;
                    highlightPos.add(match.pos().method_10063());
                    if (highlightPos.size() >= 200) break;
                }
                ServerPlayNetworking.send(player, new FindHighlightsPayload(currentDim, lastItem, highlightPos));
            } else {
                // No last find: ensure world highlights are cleared.
                ServerPlayNetworking.send(player, new FindHighlightsPayload(currentDim, "", List.of()));
            }

            // If a container is currently open, update slot highlight immediately.
            boolean highlightContainer = false;
            if (!lastItem.isEmpty() && player.field_7512 instanceof net.minecraft.class_1707 handler) {
                net.minecraft.class_1263 inv = handler.method_7629();
                for (int i = 0; i < inv.method_5439(); i++) {
                    net.minecraft.class_1799 st = inv.method_5438(i);
                    if (st == null || st.method_7960()) continue;
                    String id = String.valueOf(net.minecraft.class_7923.field_41178.method_10221(st.method_7909()));
                    if (lastItem.equals(id)) {
                        highlightContainer = true;
                        break;
                    }
                }
            }
            ServerPlayNetworking.send(player, new dev.dromer.chestsort.net.payload.ContainerHighlightPayload(lastItem, highlightContainer));

            if (untilOpened && !lastItem.isEmpty()) {
                state.armClearHighlightsOnNextOpen(uuid);
            } else {
                state.clearHighlightsOnNextOpen(uuid);
            }
        }

        source.method_9226(() -> class_2561.method_43470("[CS] Highlights mode set to: " + m), false);
        return 1;
    }

    private static int highlightsDismiss(class_2168 source) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs highlights dismiss must be run by a player"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(source.method_9211());
        String uuid = player.method_5845();
        state.setLastFindItem(uuid, "");
        state.clearHighlightsOnNextOpen(uuid);

        String currentDim = player.method_51469().method_27983().method_29177().toString();
        // Clear in-world outlines and in-container slot/text overlay.
        ServerPlayNetworking.send(player, new FindHighlightsPayload(currentDim, "", List.of()));
        ServerPlayNetworking.send(player, new dev.dromer.chestsort.net.payload.ContainerHighlightPayload("", false));

        source.method_9226(() -> class_2561.method_43470("[CS] Highlights dismissed."), false);
        return 1;
    }

    private static int presetsAdd(class_2168 source, String name) {
        MinecraftServer server = source.method_9211();
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs presets must be run by a player"));
            return 0;
        }

        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) {
            source.method_9213(class_2561.method_43470("[CS] Preset name cannot be empty"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(server);
        boolean ok = state.addPreset(n, new ContainerFilterSpec(List.of(), List.of(), List.of()));
        if (!ok) {
            source.method_9213(class_2561.method_43470("[CS] Preset already exists (or invalid name): " + n));
            return 0;
        }

        dev.dromer.chestsort.net.ChestSortNetworking.broadcastPresets(server);
        dev.dromer.chestsort.net.ChestSortNetworking.sendPresetsTo(player);
        ServerPlayNetworking.send(player, new OpenPresetUiPayload(OpenPresetUiPayload.MODE_EDIT, n));
        source.method_9226(() -> class_2561.method_43470("[CS] Added preset: " + n), false);
        return 1;
    }

    private static int presetsRemove(class_2168 source, String name) {
        MinecraftServer server = source.method_9211();
        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) {
            source.method_9213(class_2561.method_43470("[CS] Preset name cannot be empty"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(server);
        boolean removed = state.removePreset(n);
        if (!removed) {
            source.method_9213(class_2561.method_43470("[CS] Preset not found: " + n));
            return 0;
        }

        dev.dromer.chestsort.net.ChestSortNetworking.broadcastPresets(server);
        source.method_9226(() -> class_2561.method_43470("[CS] Removed preset: " + n), false);
        return 1;
    }

    private static int presetsDuplicate(class_2168 source, String name) {
        MinecraftServer server = source.method_9211();
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs presets must be run by a player"));
            return 0;
        }

        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) {
            source.method_9213(class_2561.method_43470("[CS] Preset name cannot be empty"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(server);
        if (!state.hasPreset(n)) {
            source.method_9213(class_2561.method_43470("[CS] Preset not found: " + n));
            return 0;
        }

        ContainerFilterSpec spec = state.getPresets().get(n);
        if (spec == null) {
            spec = new ContainerFilterSpec(List.of(), List.of(), List.of());
        }

        String base = n + " Copy";
        String out = base;
        if (state.hasPreset(out)) {
            for (int i = 2; i < 10_000; i++) {
                String candidate = base + " " + i;
                if (!state.hasPreset(candidate)) {
                    out = candidate;
                    break;
                }
            }
            if (state.hasPreset(out)) {
                out = base + " " + System.currentTimeMillis();
            }
        }

        state.setPreset(out, spec);
        dev.dromer.chestsort.net.ChestSortNetworking.broadcastPresets(server);
        dev.dromer.chestsort.net.ChestSortNetworking.sendPresetsTo(player);
        final String outName = out;
        source.method_9226(() -> class_2561.method_43470("[CS] Duplicated preset: " + n + " -> " + outName), false);
        return 1;
    }

    private static int presetsRename(class_2168 source, String oldName, String newName) {
        MinecraftServer server = source.method_9211();
        String o = oldName == null ? "" : oldName.trim();
        String n = newName == null ? "" : newName.trim();
        if (o.isEmpty() || n.isEmpty()) {
            source.method_9213(class_2561.method_43470("[CS] Preset names cannot be empty"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(server);
        boolean ok = state.renamePreset(o, n);
        if (!ok) {
            source.method_9213(class_2561.method_43470("[CS] Rename failed (missing old name or new name already exists)"));
            return 0;
        }

        dev.dromer.chestsort.net.ChestSortNetworking.broadcastPresets(server);
        source.method_9226(() -> class_2561.method_43470("[CS] Renamed preset: " + o + " -> " + n), false);

        class_3222 player = source.method_44023();
        if (player != null) {
            dev.dromer.chestsort.net.ChestSortNetworking.sendPresetsTo(player);
            ServerPlayNetworking.send(player, new OpenPresetUiPayload(OpenPresetUiPayload.MODE_EDIT, n));
        }
        return 1;
    }

    private static int presetsEdit(class_2168 source, String name) {
        MinecraftServer server = source.method_9211();
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs presets must be run by a player"));
            return 0;
        }

        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) {
            source.method_9213(class_2561.method_43470("[CS] Preset name cannot be empty"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(server);
        if (!state.hasPreset(n)) {
            source.method_9213(class_2561.method_43470("[CS] Preset not found: " + n));
            return 0;
        }

        dev.dromer.chestsort.net.ChestSortNetworking.sendPresetsTo(player);
        ServerPlayNetworking.send(player, new OpenPresetUiPayload(OpenPresetUiPayload.MODE_EDIT, n));
        return 1;
    }

    private static int presetsList(class_2168 source) {
        MinecraftServer server = source.method_9211();
        ChestSortState state = ChestSortState.get(server);

        java.util.ArrayList<String> names = new java.util.ArrayList<>(state.getPresets().keySet());
        names.sort(String.CASE_INSENSITIVE_ORDER);

        int total = names.size();
        if (total == 0) {
            source.method_9226(() -> class_2561.method_43470("[CS] No presets."), false);
            return 0;
        }

        source.method_9226(() -> class_2561.method_43470("[CS] Presets (" + total + "):").method_27692(class_124.field_1075), false);

        int limit = 200;
        for (int i = 0; i < names.size() && i < limit; i++) {
            String n = names.get(i);
            if (n == null || n.isEmpty()) continue;
            source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470(n).method_27692(class_124.field_1054)), false);
        }

        if (total > limit) {
            int more = total - limit;
            source.method_9226(() -> class_2561.method_43470("... and " + more + " more").method_27692(class_124.field_1080), false);
        }

        return total;
    }

    private static int presetsOpenUi(class_2168 source, byte mode, String name) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs presets must be run by a player"));
            return 0;
        }

        if (mode == OpenPresetUiPayload.MODE_EXPORT) {
            MinecraftServer server = source.method_9211();
            ChestSortState state = ChestSortState.get(server);
            String n = name == null ? "" : name.trim();
            if (n.isEmpty()) {
                source.method_9213(class_2561.method_43470("[CS] Preset name cannot be empty"));
                return 0;
            }
            if (!state.hasPreset(n)) {
                source.method_9213(class_2561.method_43470("[CS] Preset not found: " + n));
                return 0;
            }

            // Ensure the client has the latest preset definitions for exporting.
            dev.dromer.chestsort.net.ChestSortNetworking.sendPresetsTo(player);
        }

        if (mode == OpenPresetUiPayload.MODE_EXPORT_ALL) {
            // Ensure the client has the latest preset definitions for exporting.
            dev.dromer.chestsort.net.ChestSortNetworking.sendPresetsTo(player);
        }

        if (mode == OpenPresetUiPayload.MODE_EXPORT_SELECT) {
            // Ensure the client has the latest preset definitions for exporting.
            dev.dromer.chestsort.net.ChestSortNetworking.sendPresetsTo(player);
        }

        ServerPlayNetworking.send(player, new OpenPresetUiPayload(mode, name == null ? "" : name));
        return 1;
    }

    private static int scan(class_2168 source) {
        MinecraftServer server = source.method_9211();
        ChestSortState state = ChestSortState.get(server);

        int scanned = state.scanLoadedContainers(server);
        long nowMs = System.currentTimeMillis();
        state.setLastFullScanMs(nowMs);

        source.method_9226(() -> class_2561.method_43470("[CS] Scanned " + scanned + " containers at " + Instant.ofEpochMilli(nowMs)), false);
        return scanned;
    }

    private static int find(class_2168 source, class_1792 item) {
        MinecraftServer server = source.method_9211();
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs find must be run by a player"));
            return 0;
        }

        class_2960 itemId = class_7923.field_41178.method_10221(item);
        ChestSortState state = ChestSortState.get(server);
        state.setLastFindItem(player.method_5845(), itemId.toString());

        String highlightsMode = state.getHighlightsMode(player.method_5845());
        boolean highlightsOff = ChestSortState.HIGHLIGHTS_OFF.equals(highlightsMode);
        boolean untilOpened = ChestSortState.HIGHLIGHTS_UNTIL_OPENED.equals(highlightsMode);

        List<ContainerSnapshot.Match> matches = state.find(itemId.toString());
        if (matches.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("[CS] No containers found containing: " + itemId), false);
            // Clear any previous in-world highlights.
            ServerPlayNetworking.send(player, new FindHighlightsPayload(player.method_51469().method_27983().method_29177().toString(), itemId.toString(), List.of()));
            if (highlightsOff) {
                source.method_9226(() -> class_2561.method_43470("[CS] Highlights are OFF. Use /cs highlights on to enable.").method_27692(class_124.field_1080), false);
            }
            return 0;
        }

        String currentDim = player.method_51469().method_27983().method_29177().toString();
        if (highlightsOff) {
            // Ensure old outlines are removed and inform the player.
            ServerPlayNetworking.send(player, new FindHighlightsPayload(currentDim, itemId.toString(), List.of()));
            source.method_9226(() -> class_2561.method_43470("[CS] Highlights are OFF. Use /cs highlights on to enable.").method_27692(class_124.field_1080), false);
        } else {
            // Send in-world highlights for the player's current dimension only.
            java.util.ArrayList<Long> highlightPos = new java.util.ArrayList<>();
            for (ContainerSnapshot.Match m : matches) {
                if (m == null) continue;
                if (!currentDim.equals(m.dimensionId())) continue;
                if (m.pos() == null) continue;
                highlightPos.add(m.pos().method_10063());
                if (highlightPos.size() >= 200) break;
            }
            ServerPlayNetworking.send(player, new FindHighlightsPayload(currentDim, itemId.toString(), highlightPos));

            if (untilOpened) {
                state.armClearHighlightsOnNextOpen(player.method_5845());
            } else {
                state.clearHighlightsOnNextOpen(player.method_5845());
            }
        }

        source.method_9226(() -> class_2561.method_43470("[CS] Found " + matches.size() + " container(s) containing: " + itemId), false);
        for (ContainerSnapshot.Match match : matches) {
            source.method_9226(() -> class_2561.method_43470("- " + match.dimensionId() + " " + match.pos().method_23854() + " x" + match.count()), false);
        }

        return matches.size();
    }

    private static int blacklistAdd(class_2168 source, class_1792 item) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs blacklist add must be run by a player"));
            return 0;
        }
        if (item == null) {
            source.method_9213(class_2561.method_43470("[CS] Missing item"));
            return 0;
        }

        String itemId = String.valueOf(class_7923.field_41178.method_10221(item));
        ChestSortState state = ChestSortState.get(source.method_9211());
        boolean changed = state.addItemToBlacklist(player.method_5845(), itemId);
        if (changed) {
            source.method_9226(() -> class_2561.method_43470("[CS] Blacklisted: ").method_27692(class_124.field_1065)
                .method_10852(class_2561.method_43470(itemId).method_27692(class_124.field_1054)), false);
            return 1;
        }

        source.method_9226(() -> class_2561.method_43470("[CS] Already blacklisted: ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470(itemId).method_27692(class_124.field_1054)), false);
        return 0;
    }

    private static int blacklistRemove(class_2168 source, class_1792 item) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs blacklist remove must be run by a player"));
            return 0;
        }
        if (item == null) {
            source.method_9213(class_2561.method_43470("[CS] Missing item"));
            return 0;
        }

        String itemId = String.valueOf(class_7923.field_41178.method_10221(item));
        ChestSortState state = ChestSortState.get(source.method_9211());
        boolean changed = state.removeItemFromBlacklist(player.method_5845(), itemId);
        if (changed) {
            source.method_9226(() -> class_2561.method_43470("[CS] Un-blacklisted: ").method_27692(class_124.field_1065)
                .method_10852(class_2561.method_43470(itemId).method_27692(class_124.field_1054)), false);
            return 1;
        }

        source.method_9226(() -> class_2561.method_43470("[CS] Not blacklisted: ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470(itemId).method_27692(class_124.field_1054)), false);
        return 0;
    }

    private static int blacklistList(class_2168 source) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs blacklist list must be run by a player"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(source.method_9211());
        java.util.ArrayList<String> items = new java.util.ArrayList<>(state.getItemBlacklist(player.method_5845()));
        items.sort(java.util.Comparator.naturalOrder());

        source.method_9226(() -> class_2561.method_43470("[CS] ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470("Blacklisted items: ").method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(String.valueOf(items.size())).method_27692(class_124.field_1075)), false);

        if (items.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("- (none)").method_27692(class_124.field_1080), false);
            return 1;
        }

        int shown = 0;
        for (String itemId : items) {
            if (itemId == null || itemId.isEmpty()) continue;
            source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470(itemId).method_27692(class_124.field_1068)), false);
            shown++;
            if (shown >= 200) break;
        }
        return shown;
    }

    private static int blacklistClear(class_2168 source) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs blacklist clear must be run by a player"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(source.method_9211());
        int removed = state.clearItemBlacklist(player.method_5845());
        source.method_9226(() -> class_2561.method_43470("[CS] Cleared blacklist: ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470(String.valueOf(removed)).method_27692(class_124.field_1075)), false);
        return removed;
    }

    private static int blacklistMode(class_2168 source, String modeRaw) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs blacklist mode must be run by a player"));
            return 0;
        }

        ChestSortState state = ChestSortState.get(source.method_9211());
        if (modeRaw == null || modeRaw.trim().isEmpty()) {
            String current = state.getBlacklistMode(player.method_5845());
            source.method_9226(() -> class_2561.method_43470("[CS] Blacklist mode is: ").method_27692(class_124.field_1065)
                .method_10852(class_2561.method_43470(current).method_27692(class_124.field_1054)), false);
            return 1;
        }

        String m = modeRaw == null ? "" : modeRaw.trim().toLowerCase(Locale.ROOT);
        // Allow friendlier camelCase inputs.
        m = m.replace("_", "");

        if (!ChestSortState.BLACKLIST_MODE_PREVENT_SORT.equals(m)
            && !ChestSortState.BLACKLIST_MODE_STRICT_PREVENT_SORT.equals(m)
            && !ChestSortState.BLACKLIST_MODE_PREVENT_ENTRY.equals(m)
            && !ChestSortState.BLACKLIST_MODE_STRICT_PREVENT_ENTRY.equals(m)) {
            source.method_9213(class_2561.method_43470("[CS] Invalid blacklist mode. Use: preventSort | strictPreventSort | preventEntry | strictPreventEntry"));
            return 0;
        }

        final String mFinal = m;
        state.setBlacklistMode(player.method_5845(), mFinal);
        source.method_9226(() -> class_2561.method_43470("[CS] Blacklist mode set to: ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470(mFinal).method_27692(class_124.field_1054)), false);
        return 1;
    }

    private static int blacklistAddPreset(class_2168 source, String presetName, String modeRaw) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("[CS] /cs blacklist addPreset must be run by a player"));
            return 0;
        }

        String name = presetName == null ? "" : presetName.trim();
        if (name.isEmpty()) {
            source.method_9213(class_2561.method_43470("[CS] Missing preset name"));
            return 0;
        }

        String mode = modeRaw == null ? "" : modeRaw.trim().toLowerCase(Locale.ROOT);
        if (mode.isEmpty()) mode = "everything";

        final String nameFinal = name;
        final String modeFinal = mode;

        ChestSortState state = ChestSortState.get(source.method_9211());
        ContainerFilterSpec preset = state.getPreset(name);
        if (preset == null) {
            source.method_9213(class_2561.method_43470("[CS] Preset not found: " + name));
            return 0;
        }

        ContainerFilterSpec base = preset.normalized();

        ContainerFilterSpec selected;
        switch (mode) {
            case "whitelist" -> selected = new ContainerFilterSpec(base.items(), base.tags(), List.of(), false).normalized();
            case "blacklist" -> {
                // "Blacklist part" of a preset is interpreted as items/tags contributed by its applied presets.
                ContainerFilterSpec appliedOnly = new ContainerFilterSpec(List.of(), List.of(), base.presets(), false).normalized();
                selected = state.resolveWithAppliedPresets(appliedOnly);
            }
            case "everything" -> selected = state.resolveWithAppliedPresets(base);
            default -> {
                source.method_9213(class_2561.method_43470("[CS] Invalid mode: " + mode + " (use: blacklist|whitelist|everything)"));
                return 0;
            }
        }

        LinkedHashSet<String> itemIds = chestsort$collectItemIdsFromSpec(selected);
        if (itemIds.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("[CS] Preset \"" + nameFinal + "\" (" + modeFinal + ") contains no items to add."), false);
            return 1;
        }

        int added = state.addItemsToBlacklist(player.method_5845(), itemIds);
        source.method_9226(() -> class_2561.method_43470("[CS] Added ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470(String.valueOf(added)).method_27692(class_124.field_1075))
            .method_10852(class_2561.method_43470(" item(s) from preset \"").method_27692(class_124.field_1065))
            .method_10852(class_2561.method_43470(nameFinal).method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470("\" (" + modeFinal + ") to your blacklist.").method_27692(class_124.field_1065)), false);
        return Math.max(1, added);
    }

    private static LinkedHashSet<String> chestsort$collectItemIdsFromSpec(ContainerFilterSpec spec) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        if (spec == null) return out;
        ContainerFilterSpec s = spec.normalized();

        if (s.items() != null) {
            for (String raw : s.items()) {
                class_2960 id = chestsort$parseItemIdentifier(raw);
                if (id == null) continue;
                out.add(id.toString());
            }
        }

        if (s.tags() != null) {
            for (TagFilterSpec tf : s.tags()) {
                if (tf == null) continue;
                class_2960 tagId = chestsort$parseTagIdentifier(tf.tagId());
                if (tagId == null) continue;

                HashSet<String> exc = chestsort$expandExceptionsToItemIds(tf.exceptions());
                class_6862<class_1792> tagKey = class_6862.method_40092(class_7924.field_41197, tagId);
                for (var entry : class_7923.field_41178.method_40286(tagKey)) {
                    if (entry == null || entry.comp_349() == null) continue;
                    String itemId = String.valueOf(class_7923.field_41178.method_10221(entry.comp_349()));
                    if (itemId == null || itemId.isEmpty()) continue;
                    if (exc.contains(itemId)) continue;
                    out.add(itemId);
                }
            }
        }

        return out;
    }

    private static HashSet<String> chestsort$expandExceptionsToItemIds(List<String> exceptions) {
        HashSet<String> out = new HashSet<>();
        if (exceptions == null || exceptions.isEmpty()) return out;

        for (String raw : exceptions) {
            if (raw == null) continue;
            String t = raw.trim();
            if (t.isEmpty()) continue;

            if (t.startsWith("#")) {
                class_2960 tagId = chestsort$parseTagIdentifier(t);
                if (tagId == null) continue;
                class_6862<class_1792> tagKey = class_6862.method_40092(class_7924.field_41197, tagId);
                for (var entry : class_7923.field_41178.method_40286(tagKey)) {
                    if (entry == null || entry.comp_349() == null) continue;
                    String itemId = String.valueOf(class_7923.field_41178.method_10221(entry.comp_349()));
                    if (itemId == null || itemId.isEmpty()) continue;
                    out.add(itemId);
                }
            } else {
                class_2960 id = chestsort$parseItemIdentifier(t);
                if (id == null) continue;
                out.add(id.toString());
            }
        }

        return out;
    }

    private static class_2960 chestsort$parseItemIdentifier(String itemId) {
        if (itemId == null) return null;
        String t = itemId.trim();
        if (t.isEmpty()) return null;
        class_2960 id = class_2960.method_12829(t);
        if (id != null) return id;
        if (t.indexOf(':') < 0) {
            return class_2960.method_12829("minecraft:" + t);
        }
        return null;
    }

    private static class_2960 chestsort$parseTagIdentifier(String tagId) {
        if (tagId == null) return null;
        String t = tagId.trim();
        if (t.isEmpty()) return null;
        if (t.startsWith("#")) t = t.substring(1);

        class_2960 id = class_2960.method_12829(t);
        if (id != null) return id;
        if (t.indexOf(':') < 0) {
            return class_2960.method_12829("minecraft:" + t);
        }
        return null;
    }

    private static int tags(class_2168 source, class_1792 item) {
        if (item == null) {
            source.method_9213(class_2561.method_43470("[CS] Missing item"));
            return 0;
        }

        class_2960 itemId = class_7923.field_41178.method_10221(item);
        java.util.ArrayList<String> tags = new java.util.ArrayList<>();

        try {
            // Modern registry API: items expose their tag memberships via their registry entry.
            for (class_6862<class_1792> tag : item.method_40131().method_40228().toList()) {
                if (tag == null || tag.comp_327() == null) continue;
                tags.add("#" + tag.comp_327());
            }
        } catch (Throwable t) {
            // Fallback for mappings/versions where streamTags() may not be available.
            // (We keep this graceful rather than hard-crashing the command.)
            source.method_9213(class_2561.method_43470("[CS] Failed to read tags for: " + itemId));
            return 0;
        }

        java.util.Collections.sort(tags);

        source.method_9226(() -> class_2561.method_43470("[CS] ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470("Tags for ").method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(itemId.toString()).method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(": ").method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(String.valueOf(tags.size())).method_27692(class_124.field_1075)), false);

        if (tags.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("- (none)").method_27692(class_124.field_1080), false);
            return 1;
        }

        for (String tag : tags) {
            source.method_9226(() -> class_2561.method_43470("- ").method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470(tag).method_27692(class_124.field_1076)), false);
        }

        return tags.size();
    }
}
