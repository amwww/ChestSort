package dev.dromer.chestsort.client.gui;

import java.util.List;
import net.minecraft.class_11908;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import dev.dromer.chestsort.client.ClientNetworkingUtil;
import dev.dromer.chestsort.client.ClientPresetRegistry;
import dev.dromer.chestsort.filter.ContainerFilterSpec;
import dev.dromer.chestsort.net.payload.ImportPresetPayload;
import dev.dromer.chestsort.util.Cs2StringCodec;

public final class PresetTransferScreen extends class_437 {
    public enum Mode {
        IMPORT,
        EXPORT,
        EXPORT_ALL
    }

    private static final String PREFIX = "cs2|";

    private final Mode mode;
    private final String exportPresetName;

    private class_342 field;
    private class_4185 primaryButton;
    private class_4185 secondaryButton;

    private String error = "";

    private record ComputeResult(String text, String error) {
    }

    public PresetTransferScreen(Mode mode, String presetName) {
        super(class_2561.method_43470(mode == Mode.IMPORT ? "Import preset" : (mode == Mode.EXPORT_ALL ? "Export all presets" : "Export preset")));
        this.mode = mode == null ? Mode.IMPORT : mode;
        this.exportPresetName = presetName == null ? "" : presetName.trim();
    }

    @Override
    protected void method_25426() {
        this.error = "";

        int boxW = Math.min(320, Math.max(180, this.field_22789 - 40));
        int x = (this.field_22789 - boxW) / 2;
        int y = Math.max(20, (this.field_22790 - 120) / 2);

        this.field = new class_342(this.field_22793, x, y + 28, boxW, 20, class_2561.method_43470(""));
        this.field.method_1880(32767);
        this.method_37063(this.field);

        if (this.mode == Mode.IMPORT) {
            this.field.method_1888(true);
            this.field.method_1852("");
            this.field.method_25365(true);

            this.primaryButton = class_4185.method_46430(class_2561.method_43470("Import"), b -> tryImport())
                .method_46434(x, y + 56, (boxW - 6) / 2, 20)
                .method_46431();
            this.secondaryButton = class_4185.method_46430(class_2561.method_43470("Cancel"), b -> this.method_25419())
                .method_46434(x + (boxW - 6) / 2 + 6, y + 56, (boxW - 6) / 2, 20)
                .method_46431();
            this.method_37063(this.primaryButton);
            this.method_37063(this.secondaryButton);
        } else {
            this.field.method_1888(false);
            this.field.method_25365(true);

            // Computing exports can be expensive for large presets; do it off-thread.
            this.field.method_1852("Loading...");

            Thread t = new Thread(() -> {
                ComputeResult r = computeExport();
                class_310 mc = class_310.method_1551();
                if (mc == null) return;
                mc.execute(() -> {
                    this.error = (r == null || r.error == null) ? "" : r.error;
                    if (this.field != null) {
                        String text = (r == null || r.text == null) ? "" : r.text;
                        // Keep UI responsive and avoid pathological giant strings.
                        if (text.length() > 32767) {
                            this.error = (this.error == null || this.error.isEmpty())
                                ? ("Export too large to display (len=" + text.length() + ")")
                                : this.error;
                            text = text.substring(0, 32767);
                        }
                        this.field.method_1852(text);
                    }
                });
            }, "ChestSort preset export");
            t.setDaemon(true);
            t.start();

            this.primaryButton = class_4185.method_46430(class_2561.method_43470("Close"), b -> this.method_25419())
                .method_46434(x, y + 56, boxW, 20)
                .method_46431();
            this.method_37063(this.primaryButton);
        }
    }

    private void tryImport() {
        String raw = this.field == null ? "" : this.field.method_1882();
        if (raw == null || raw.trim().isEmpty()) {
            this.error = "empty";
            return;
        }

        // If this is a presetList, offer a selection + rename UI.
        try {
            var decoded = Cs2StringCodec.decodePresetList(raw);
            if (decoded != null && decoded.whitelists() != null && !decoded.whitelists().isEmpty()) {
                class_310.method_1551().method_1507(PresetListTransferScreen.forImportList(raw));
                return;
            }
        } catch (IllegalArgumentException ignored) {
            // Not a presetList; fall through to single preset import.
        }

        boolean sent = ClientNetworkingUtil.sendSafe(new ImportPresetPayload(raw));
        if (!sent) {
            try {
                var decoded = Cs2StringCodec.decodePresetImport(raw);
                ClientPresetRegistry.putLocal(decoded.name(), decoded.whitelist());
                ClientPresetRegistry.putLocalBlacklist(decoded.name(), decoded.blacklist());
            } catch (IllegalArgumentException e) {
                this.error = e.getMessage();
                return;
            }
        }
        this.method_25419();
    }

    private ComputeResult computeExport() {
        if (this.mode == Mode.EXPORT_ALL) {
            try {
                var allWl = ClientPresetRegistry.all();
                var allBl = ClientPresetRegistry.allBlacklists();
                if ((allWl == null || allWl.isEmpty()) && (allBl == null || allBl.isEmpty())) {
                    return new ComputeResult("", "No presets");
                }

                java.util.LinkedHashMap<String, ContainerFilterSpec> orderedWl = new java.util.LinkedHashMap<>();
                java.util.LinkedHashMap<String, ContainerFilterSpec> orderedBl = new java.util.LinkedHashMap<>();
                for (String name : ClientPresetRegistry.namesSorted()) {
                    if (name == null) continue;
                    String n = name.trim();
                    if (n.isEmpty()) continue;

                    ContainerFilterSpec wl = allWl == null ? null : allWl.get(n);
                    ContainerFilterSpec bl = allBl == null ? null : allBl.get(n);
                    if ((wl == null || wl.isEmpty()) && (bl == null || bl.isEmpty())) continue;

                    orderedWl.put(n, wl == null ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : wl);
                    if (bl != null && !bl.isEmpty()) {
                        orderedBl.put(n, bl);
                    }
                }

                if (orderedWl.isEmpty()) {
                    return new ComputeResult("", "No presets");
                }

                return new ComputeResult(Cs2StringCodec.encodePresetList(orderedWl, orderedBl), "");
            } catch (Throwable t) {
                String msg = t.getMessage();
                if (msg == null || msg.isEmpty()) msg = t.getClass().getSimpleName();
                return new ComputeResult("", msg);
            }
        }

        if (this.exportPresetName.isEmpty()) {
            return new ComputeResult("", "No preset name");
        }
        try {
            ContainerFilterSpec wl = ClientPresetRegistry.get(this.exportPresetName);
            ContainerFilterSpec bl = ClientPresetRegistry.getBlacklist(this.exportPresetName);
            if ((wl == null || wl.isEmpty()) && (bl == null || bl.isEmpty())) {
                return new ComputeResult("", "No preset / empty");
            }
            ContainerFilterSpec safeWl = wl == null ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : wl;
            ContainerFilterSpec safeBl = bl == null ? new ContainerFilterSpec(List.of(), List.of(), List.of()) : bl;
            return new ComputeResult(encode(this.exportPresetName, safeWl, safeBl), "");
        } catch (Throwable t) {
            String msg = t.getMessage();
            if (msg == null || msg.isEmpty()) msg = t.getClass().getSimpleName();
            return new ComputeResult("", msg);
        }
    }

    private static String encode(String presetName, ContainerFilterSpec whitelist, ContainerFilterSpec blacklist) {
        // Keep PREFIX constant for UI text, but use the shared codec.
        return Cs2StringCodec.encodePreset(presetName, whitelist, blacklist);
    }

    @SuppressWarnings("unused")
    private static ContainerFilterSpec decode(String raw) {
        return Cs2StringCodec.decodeSpec(raw);
    }

    @Override
    public boolean method_25404(class_11908 keyInput) {
        class_310 client = class_310.method_1551();

        boolean focused = this.field != null && this.field.field_22764 && this.field.method_25370();
        if (focused && this.field.method_25404(keyInput)) {
            return true;
        }

        if (client != null && client.field_1690 != null && client.field_1690.field_1881 != null && client.field_1690.field_1881.method_1417(keyInput)) {
            this.method_25419();
            return true;
        }

        if (this.mode == Mode.IMPORT && (keyInput.comp_4795() == org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER || keyInput.comp_4795() == org.lwjgl.glfw.GLFW.GLFW_KEY_KP_ENTER)) {
            tryImport();
            return true;
        }

        return super.method_25404(keyInput);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Avoid Screen.renderBackground(), which applies the GUI blur effect.
        // In newer Minecraft versions, blur can only be applied once per frame.
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xAA000000);

        int boxW = Math.min(320, Math.max(180, this.field_22789 - 40));
        int x = (this.field_22789 - boxW) / 2;
        int y = Math.max(20, (this.field_22790 - 120) / 2);

        context.method_25294(x - 8, y - 12, x + boxW + 8, y + 92, 0xAA000000);

        String title = this.mode == Mode.IMPORT
            ? "Import preset"
            : (this.mode == Mode.EXPORT_ALL
                ? "Export all presets"
                : (this.exportPresetName.isEmpty() ? "Export preset" : ("Export preset: " + this.exportPresetName)));

        context.method_27535(this.field_22793, class_2561.method_43470(title), x, y - 2, 0xFFFFFFFF);

        if (this.mode == Mode.IMPORT) {
            context.method_27535(this.field_22793, class_2561.method_43470("Paste cs2|preset/<name>| or cs2|presetList|"), x, y + 12, 0xFFAAAAAA);
        } else {
            context.method_27535(this.field_22793, class_2561.method_43470("Select + copy from box"), x, y + 12, 0xFFAAAAAA);
        }

        if (this.error != null && !this.error.isEmpty()) {
            context.method_27535(this.field_22793, class_2561.method_43470(this.error).method_27692(class_124.field_1061), x, y + 80, 0xFFFFFFFF);
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(null);
    }
}
