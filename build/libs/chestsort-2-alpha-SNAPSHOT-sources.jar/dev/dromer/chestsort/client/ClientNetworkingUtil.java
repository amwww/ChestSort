package dev.dromer.chestsort.client;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_8710;

public final class ClientNetworkingUtil {
    private ClientNetworkingUtil() {
    }

    public static boolean canSend(class_8710.class_9154<?> id) {
        if (id == null) return false;
        try {
            return ClientPlayNetworking.canSend(id);
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean sendSafe(class_8710 payload) {
        if (payload == null) return false;
        if (!canSend(payload.method_56479())) return false;
        ClientPlayNetworking.send(payload);
        return true;
    }
}
