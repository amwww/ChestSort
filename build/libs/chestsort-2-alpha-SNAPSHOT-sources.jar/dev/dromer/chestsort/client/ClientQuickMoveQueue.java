package dev.dromer.chestsort.client;

import java.util.ArrayDeque;
import java.util.Collection;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_310;
import net.minecraft.class_465;

/**
 * Runs a sequence of vanilla QUICK_MOVE (shift-click) slot clicks over time.
 * This is used as a fallback on servers that don't have ChestSort installed.
 */
public final class ClientQuickMoveQueue {
    private static final ArrayDeque<Integer> pendingSlotIds = new ArrayDeque<>();
    private static int pendingSyncId = -1;
    private static Runnable onDone;

    private ClientQuickMoveQueue() {
    }

    public static boolean isActive() {
        return !pendingSlotIds.isEmpty();
    }

    public static void clear() {
        pendingSlotIds.clear();
        pendingSyncId = -1;
        onDone = null;
    }

    public static void start(class_1703 handler, Collection<Integer> slotIds, Runnable onDoneCallback) {
        clear();
        if (handler == null || slotIds == null || slotIds.isEmpty()) return;
        pendingSyncId = handler.field_7763;
        pendingSlotIds.addAll(slotIds);
        onDone = onDoneCallback;
    }

    public static void tick(class_310 client) {
        if (client == null) return;
        if (ClientClickQueue.isActive()) return;
        if (pendingSlotIds.isEmpty()) return;

        if (client.field_1724 == null || client.field_1761 == null) {
            clear();
            return;
        }

        if (!(client.field_1755 instanceof class_465<?> handled)) {
            clear();
            return;
        }

        class_1703 handler = handled.method_17577();
        if (handler == null || handler.field_7763 != pendingSyncId) {
            clear();
            return;
        }

        Integer slotId = pendingSlotIds.pollFirst();
        if (slotId == null) {
            clear();
            return;
        }

        client.field_1761.method_2906(handler.field_7763, slotId, 0, class_1713.field_7794, client.field_1724);

        if (pendingSlotIds.isEmpty()) {
            Runnable done = onDone;
            clear();
            if (done != null) done.run();
        }
    }
}
