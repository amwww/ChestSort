package dev.dromer.chestsort.client;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class ClientOnlyOrganizer {
    private ClientOnlyOrganizer() {
    }

    public static void organizeOpenContainer(class_310 client, class_1703 handler) {
        if (client == null || handler == null || client.field_1724 == null) return;

        if (ClientClickQueue.isActive() || ClientQuickMoveQueue.isActive()) {
            client.field_1724.method_7353(class_2561.method_43470("ChestSort: Busy (action queue running)."), true);
            return;
        }

        if (!handler.method_34255().method_7960()) {
            client.field_1724.method_7353(class_2561.method_43470("ChestSort: Clear your cursor stack first."), true);
            return;
        }

        class_1661 playerInv = client.field_1724.method_31548();

        List<class_1735> containerSlots = new ArrayList<>();
        for (class_1735 slot : handler.field_7761) {
            if (slot == null) continue;
            if (slot.field_7871 == playerInv) continue;
            containerSlots.add(slot);
        }

        containerSlots.sort(Comparator.comparingInt((class_1735 s) -> s.field_7872).thenComparingInt(s -> s.field_7873));

        List<ClientClickQueue.ClickAction> actions = new ArrayList<>();

        // Pass 1: merge identical stacks into earlier slots.
        for (int targetIndex = 0; targetIndex < containerSlots.size(); targetIndex++) {
            class_1735 targetSlot = containerSlots.get(targetIndex);
            class_1799 targetStack = targetSlot.method_7677();
            if (targetStack.method_7960()) continue;

            int targetMax = targetStack.method_7914();
            if (targetStack.method_7947() >= targetMax) continue;

            for (int sourceIndex = targetIndex + 1; sourceIndex < containerSlots.size(); sourceIndex++) {
                class_1735 sourceSlot = containerSlots.get(sourceIndex);
                class_1799 sourceStack = sourceSlot.method_7677();
                if (sourceStack.method_7960()) continue;

                if (!class_1799.method_31577(targetStack, sourceStack)) continue;

                actions.add(new ClientClickQueue.ClickAction(sourceSlot.field_7874, 0, class_1713.field_7790));
                actions.add(new ClientClickQueue.ClickAction(targetSlot.field_7874, 0, class_1713.field_7790));
                actions.add(new ClientClickQueue.ClickAction(sourceSlot.field_7874, 0, class_1713.field_7790));

                // We can't perfectly predict post-click counts client-side with latency, so just plan merges opportunistically.
            }
        }

        // Pass 2: fill earlier empty slots (compact) by moving later stacks forward.
        for (int targetIndex = 0; targetIndex < containerSlots.size(); targetIndex++) {
            class_1735 targetSlot = containerSlots.get(targetIndex);
            if (!targetSlot.method_7677().method_7960()) continue;

            int sourceIndex = -1;
            for (int i = targetIndex + 1; i < containerSlots.size(); i++) {
                if (!containerSlots.get(i).method_7677().method_7960()) {
                    sourceIndex = i;
                    break;
                }
            }
            if (sourceIndex == -1) break;

            class_1735 sourceSlot = containerSlots.get(sourceIndex);

            actions.add(new ClientClickQueue.ClickAction(sourceSlot.field_7874, 0, class_1713.field_7790));
            actions.add(new ClientClickQueue.ClickAction(targetSlot.field_7874, 0, class_1713.field_7790));
            actions.add(new ClientClickQueue.ClickAction(sourceSlot.field_7874, 0, class_1713.field_7790));
        }

        if (actions.isEmpty()) {
            client.field_1724.method_7353(class_2561.method_43470("ChestSort: Nothing to organize."), true);
            return;
        }

        ClientClickQueue.start(handler, actions, () -> {
            if (client.field_1724 != null) {
                client.field_1724.method_7353(class_2561.method_43470("ChestSort: Organize complete."), true);
            }
        });

        client.field_1724.method_7353(class_2561.method_43470("ChestSort: Organizing (client-side)…"), true);
    }
}
