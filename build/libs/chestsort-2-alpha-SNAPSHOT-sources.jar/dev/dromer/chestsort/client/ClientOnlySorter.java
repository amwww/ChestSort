package dev.dromer.chestsort.client;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import dev.dromer.chestsort.filter.ContainerFilterSpec;
import dev.dromer.chestsort.net.ChestSortNetworking;

public final class ClientOnlySorter {
    private ClientOnlySorter() {
    }

    /**
     * Fallback sort: moves matching items from the player's inventory into the open container using vanilla QUICK_MOVE.
     */
    public static void sortIntoOpenContainer(class_310 client, class_1703 handler, ContainerFilterSpec whitelistBase, ContainerFilterSpec blacklistBase, boolean whitelistPriority) {
        if (client == null || client.field_1724 == null) return;
        if (handler == null || handler.field_7761 == null) return;

        if (ClientClickQueue.isActive() || ClientQuickMoveQueue.isActive()) {
            client.field_1724.method_7353(class_2561.method_43470("[ChestSort] Busy (action queue running)").method_27692(class_124.field_1080), false);
            return;
        }

        class_1661 playerInv = client.field_1724.method_31548();
        if (playerInv == null) return;

        ContainerFilterSpec effectiveWhitelist = ClientFilterResolver.resolveWithAppliedPresets(whitelistBase);
        ContainerFilterSpec effectiveBlacklist = ClientFilterResolver.resolveBlacklistWithAppliedPresets(blacklistBase);

        Set<String> allowedItemIds = new HashSet<>(effectiveWhitelist.items() == null ? List.of() : effectiveWhitelist.items());
        List<ChestSortNetworking.TagFilterRuntime> whitelistTagFilters = ChestSortNetworking.compileTagFilters(effectiveWhitelist.tags());

        Set<String> blockedItemIds = new HashSet<>(effectiveBlacklist.items() == null ? List.of() : effectiveBlacklist.items());
        List<ChestSortNetworking.TagFilterRuntime> blacklistTagFilters = ChestSortNetworking.compileTagFilters(effectiveBlacklist.tags());

        ArrayList<Integer> slotIdsToMove = new ArrayList<>();

        for (int slotId = 0; slotId < handler.field_7761.size(); slotId++) {
            class_1735 slot = handler.field_7761.get(slotId);
            if (slot == null) continue;
            if (slot.field_7871 != playerInv) continue;

            int playerIndex = slot.method_34266();
            if (ClientLockedSlotsState.isLocked(playerIndex)) continue;

            class_1799 stack = slot.method_7677();
            if (stack == null || stack.method_7960()) continue;

            String itemId = String.valueOf(class_7923.field_41178.method_10221(stack.method_7909()));

            boolean allowed = allowedItemIds.contains(itemId);
            if (!allowed) {
                for (ChestSortNetworking.TagFilterRuntime tf : whitelistTagFilters) {
                    if (tf.matches(stack, itemId)) {
                        allowed = true;
                        break;
                    }
                }
            }
            if (!allowed) continue;

            boolean blocked = blockedItemIds.contains(itemId);
            if (!blocked) {
                for (ChestSortNetworking.TagFilterRuntime tf : blacklistTagFilters) {
                    if (tf.matches(stack, itemId)) {
                        blocked = true;
                        break;
                    }
                }
            }
            if (blocked && !whitelistPriority) continue;

            slotIdsToMove.add(slotId);
        }

        if (slotIdsToMove.isEmpty()) {
            client.field_1724.method_7353(class_2561.method_43470("[ChestSort] Nothing to move").method_27692(class_124.field_1080), false);
            return;
        }

        client.field_1724.method_7353(class_2561.method_43470("[ChestSort] Sorting (client-only)...").method_27692(class_124.field_1054), false);

        ClientQuickMoveQueue.start(handler, slotIdsToMove, () -> {
            var p = class_310.method_1551().field_1724;
            if (p != null) {
                p.method_7353(class_2561.method_43470("[ChestSort] Done").method_27692(class_124.field_1080), false);
            }
        });
    }
}
