package dev.dromer.chestsort.client;

import java.util.ArrayDeque;
import java.util.Collection;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_310;
import net.minecraft.class_465;

/** Runs a sequence of vanilla slot click actions over time (one per tick). */
public final class ClientClickQueue {
    public record ClickAction(int slotId, int button, class_1713 actionType) {
    }

    private static final ArrayDeque<ClickAction> pending = new ArrayDeque<>();
    private static int pendingSyncId = -1;
    private static Runnable onDone;

    private ClientClickQueue() {
    }

    public static boolean isActive() {
        return !pending.isEmpty();
    }

    public static void clear() {
        pending.clear();
        pendingSyncId = -1;
        onDone = null;
    }

    public static void start(class_1703 handler, Collection<ClickAction> actions, Runnable onDoneCallback) {
        clear();
        if (handler == null || actions == null || actions.isEmpty()) return;
        pendingSyncId = handler.field_7763;
        pending.addAll(actions);
        onDone = onDoneCallback;
    }

    public static void tick(class_310 client) {
        if (client == null) return;
        if (pending.isEmpty()) return;

        if (client.field_1724 == null || client.field_1761 == null) {
            clear();
            return;
        }

        if (!(client.field_1755 instanceof class_465<?> handled)) {
            clear();
            return;
        }

        class_1703 handler = handled.method_17577();
        if (handler == null || handler.field_7763 != pendingSyncId) {
            clear();
            return;
        }

        ClickAction action = pending.pollFirst();
        if (action == null) {
            clear();
            return;
        }

        client.field_1761.method_2906(handler.field_7763, action.slotId(), action.button(), action.actionType(), client.field_1724);

        if (pending.isEmpty()) {
            Runnable done = onDone;
            clear();
            if (done != null) done.run();
        }
    }
}
