package dev.dromer.chestsort.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import dev.dromer.chestsort.client.ClientLastInteractedBlock;
import dev.dromer.chestsort.client.ClientNetworkingUtil;
import dev.dromer.chestsort.client.ClientWandSelectionState;
import dev.dromer.chestsort.net.payload.WandSelectPayload;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_7923;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {

    private static boolean chestsort$isHoldingWand() {
        var mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null) return false;

        String wandItemId = ClientWandSelectionState.wandItemId();
        if (wandItemId == null || wandItemId.isEmpty()) return false;

        String heldId = String.valueOf(class_7923.field_41178.method_10221(mc.field_1724.method_6047().method_7909()));
        String offId = String.valueOf(class_7923.field_41178.method_10221(mc.field_1724.method_6079().method_7909()));
        return wandItemId.equals(heldId) || wandItemId.equals(offId);
    }

    @Inject(method = "attackBlock", at = @At("HEAD"), cancellable = true)
    private void chestsort$wandAttack(class_2338 pos, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
        var mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null) return;
        if (!chestsort$isHoldingWand()) return;

        String dimId = mc.field_1687.method_27983().method_29177().toString();
        ClientNetworkingUtil.sendSafe(new WandSelectPayload((byte) 1, dimId, pos.method_10063()));

        // Prevent client-side breaking/prediction.
        cir.setReturnValue(false);
        cir.cancel();
    }

    @Inject(method = "updateBlockBreakingProgress", at = @At("HEAD"), cancellable = true)
    private void chestsort$wandUpdateBreaking(class_2338 pos, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
        if (!chestsort$isHoldingWand()) return;
        // Extra safety for creative-mode instant breaking paths.
        cir.setReturnValue(false);
        cir.cancel();
    }

    @Inject(method = "interactBlock", at = @At("HEAD"), cancellable = true)
    private void chestsort$wandUseBlock(net.minecraft.class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
        var mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null) return;

        if (hitResult != null && hitResult.method_17777() != null) {
            String dimId = mc.field_1687.method_27983().method_29177().toString();
            class_2338 pos = hitResult.method_17777();
            ClientLastInteractedBlock.set(dimId, pos.method_10063());
        }

        String wandItemId = ClientWandSelectionState.wandItemId();
        if (wandItemId == null || wandItemId.isEmpty()) return;

        String heldId = String.valueOf(class_7923.field_41178.method_10221(mc.field_1724.method_5998(hand).method_7909()));
        if (!wandItemId.equals(heldId)) return;

        class_2338 pos = hitResult.method_17777();
        String dimId = mc.field_1687.method_27983().method_29177().toString();
        ClientNetworkingUtil.sendSafe(new WandSelectPayload((byte) 2, dimId, pos.method_10063()));

        // Prevent opening/using blocks while selecting.
        cir.setReturnValue(class_1269.field_5812);
        cir.cancel();
    }
}
