package dev.dromer.chestsort.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.dromer.chestsort.data.ChestSortState;
import dev.dromer.chestsort.filter.ContainerFilterSpec;
import dev.dromer.chestsort.net.ChestSortNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2813;
import net.minecraft.class_2846;
import net.minecraft.class_2873;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_7923;

@Mixin(class_3244.class)
public class ServerPlayNetworkHandlerMixin {

    @Shadow
    public class_3222 player;

    @Inject(method = "onPlayerAction", at = @At("HEAD"), cancellable = true)
    private void chestsort$wandSelectPos1(class_2846 packet, CallbackInfo ci) {
        if (player == null) return;
        if (!(player.method_51469() instanceof class_3218 world)) return;
        if (packet == null) return;
        if (packet.method_12363() != class_2846.class_2847.field_12968) return;

        ChestSortState state = ChestSortState.get(world.method_8503());
        String uuid = player.method_5845();
        String wandItemId = state.getWandItemId(uuid);
        if (wandItemId == null || wandItemId.isEmpty()) return;

        boolean holdingWand = false;
        if (!player.method_6047().method_7960()) {
            String id = String.valueOf(class_7923.field_41178.method_10221(player.method_6047().method_7909()));
            holdingWand = wandItemId.equals(id);
        }
        if (!holdingWand && !player.method_6079().method_7960()) {
            String id = String.valueOf(class_7923.field_41178.method_10221(player.method_6079().method_7909()));
            holdingWand = wandItemId.equals(id);
        }
        if (!holdingWand) return;

        class_2338 pos = packet.method_12362();
        if (pos == null) return;

        String dimId = world.method_27983().method_29177().toString();
        state.setWandPos1(uuid, dimId, pos.method_10063());
        player.method_7353(class_2561.method_43470("[CS] ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470("Wand pos1 set to ").method_27692(class_124.field_1080))
            .method_10852(class_2561.method_43470(pos.method_10263() + " " + pos.method_10264() + " " + pos.method_10260()).method_27692(class_124.field_1054)), false);

        // Prevent breaking blocks while selecting.
        ci.cancel();
    }

    @Inject(method = "onClickSlot", at = @At("HEAD"), cancellable = true)
    private void chestsort$preventBlacklistedEntry(class_2813 packet, CallbackInfo ci) {
        if (player == null) return;
        if (!(player.method_51469() instanceof class_3218 world)) return;
        if (packet == null) return;

        ChestSortState state = ChestSortState.get(world.method_8503());
        String uuid = player.method_5845();
        String mode = state.getBlacklistMode(uuid);
        if (!ChestSortState.blacklistModePreventsEntry(mode)) return;

        if (!(player.field_7512 instanceof class_1707 handler)) return;

        int slot = packet.comp_3844();
        class_1713 action = packet.comp_3846();
        if (action == null) return;

        int containerSize = handler.method_7629().method_5439();
        boolean strict = ChestSortState.BLACKLIST_MODE_STRICT_PREVENT_ENTRY.equals(mode);

        // Helper: check blacklist + optional whitelist override.
        java.util.function.Predicate<class_1799> shouldBlock = (stack) -> {
            if (stack == null || stack.method_7960()) return false;
            String itemId = String.valueOf(class_7923.field_41178.method_10221(stack.method_7909()));
            if (!state.isItemBlacklisted(uuid, itemId)) return false;
            if (strict) return true;
            // preventEntry: allow if whitelisted AND whitelistPriority enabled for this container.
            if (chestsort$isWhitelistedInOpenContainer(state, uuid, stack, itemId)) return false;
            return true;
        };

        // 1) Drag-split / drag-place (QUICK_CRAFT): packets often use slot=-999, so detect if any
        // modified slot is a container slot.
        if (action == class_1713.field_7789) {
            boolean touchesContainer = false;
            var modified = packet.comp_3847();
            if (modified != null && !modified.isEmpty()) {
                for (var e : modified.int2ObjectEntrySet()) {
                    int idx = e.getIntKey();
                    if (idx >= 0 && idx < containerSize) {
                        touchesContainer = true;
                        break;
                    }
                }
            }
            if (touchesContainer) {
                class_1799 cursor = handler.method_34255();
                if (shouldBlock.test(cursor)) {
                    ci.cancel();
                    handler.method_7623();
                }
            }
            return;
        }

        // 2) Normal click placing cursor stack into a container slot.
        if (action == class_1713.field_7790 && slot >= 0 && slot < containerSize) {
            class_1799 cursor = handler.method_34255();
            if (shouldBlock.test(cursor)) {
                ci.cancel();
                handler.method_7623();
            }
            return;
        }

        // 3) Shift-click from player inventory into container.
        if (action == class_1713.field_7794 && slot >= containerSize) {
            class_1799 clicked = handler.method_7611(slot).method_7677();
            if (shouldBlock.test(clicked)) {
                ci.cancel();
                handler.method_7623();
            }
            return;
        }

        // 4) Number-key swap from hotbar into a container slot.
        if (action == class_1713.field_7791 && slot >= 0 && slot < containerSize) {
            int hotbar = packet.comp_3845();
            if (hotbar >= 0 && hotbar < 9) {
                class_1799 hotbarStack = player.method_31548().method_5438(hotbar);
                if (shouldBlock.test(hotbarStack)) {
                    ci.cancel();
                    handler.method_7623();
                }
            }
        }
    }

    @Inject(method = "onCreativeInventoryAction", at = @At("HEAD"), cancellable = true)
    private void chestsort$preventBlacklistedEntryCreative(class_2873 packet, CallbackInfo ci) {
        if (player == null) return;
        if (!(player.method_51469() instanceof class_3218 world)) return;
        if (packet == null) return;

        ChestSortState state = ChestSortState.get(world.method_8503());
        String uuid = player.method_5845();
        String mode = state.getBlacklistMode(uuid);
        if (!ChestSortState.blacklistModePreventsEntry(mode)) return;

        // Only applies to generic containers (chests/barrels/shulkers).
        if (!(player.field_7512 instanceof class_1707 handler)) return;

        int containerSize = handler.method_7629().method_5439();
        int slot = packet.comp_2609();
        if (slot < 0 || slot >= containerSize) return;

        class_1799 stack = packet.comp_2610();
        if (stack == null || stack.method_7960()) return;

        String itemId = String.valueOf(class_7923.field_41178.method_10221(stack.method_7909()));
        if (!state.isItemBlacklisted(uuid, itemId)) return;

        boolean strict = ChestSortState.BLACKLIST_MODE_STRICT_PREVENT_ENTRY.equals(mode);
        if (!strict && chestsort$isWhitelistedInOpenContainer(state, uuid, stack, itemId)) return;

        ci.cancel();
        handler.method_7623();
    }

    private static boolean chestsort$isWhitelistedInOpenContainer(ChestSortState state, String playerUuid, class_1799 stack, String itemId) {
        if (state == null) return false;
        if (playerUuid == null || playerUuid.isEmpty()) return false;
        ChestSortState.OpenContainerRef open = state.getOpenContainer(playerUuid);
        if (open == null) return false;

        boolean whitelistPriority = state.whitelistPriority(open.dimensionId(), open.posLong());
        if (!whitelistPriority) return false;

        ContainerFilterSpec base = state.getFilterSpec(open.dimensionId(), open.posLong());
        if (base == null || base.isEmpty()) return false;

        ContainerFilterSpec effective = state.resolveWithAppliedPresets(base);
        if (effective == null || effective.isEmpty()) return false;

        ContainerFilterSpec w = effective.normalized();
        if (w.items() != null && w.items().contains(itemId)) return true;

        for (ChestSortNetworking.TagFilterRuntime tf : ChestSortNetworking.compileTagFilters(w.tags())) {
            if (tf.matches(stack, itemId)) return true;
        }

        return false;
    }
}
